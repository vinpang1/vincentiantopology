# 5_external · pyramids-series

> **zip 施工** next 5 ✅（零外參 · 封板）  
> **藍圖** `tZpBp701` §8 · 與 `3_citations/`（Spin Map B/A）**分櫃**

## 狀態

本 topic **無** `external_*` 登記列 · **無** `VT_ext_*` uuid · `attachments/` 空置。

| 檢查 | 結果 |
|------|------|
| 四期 `article.md` 內嵌 YouTube／網文外參 | 無 |
| 各 slug `sources.md` 外參候選 | 僅 B/A 引述 + fetch T2（已入 `3_citations/`） |
| `external_candidates_*.json` | 無金字塔系列專檔 |
| Ep4 陰謀演練 | **自產敘事演練** · 非 `5_external` |

## 日後若加外參

1. 厚筆記 → `5_external/VT_ext_*.md`（或 `5_external/{slug}.md` + shadow 指標）  
2. shadow → `4_md/VT_ext_*.md`  
3. CSV 行 · `item_type` = `external_youtube`｜`external_web`｜`external_article`｜`external_fetch`  
4. `topo_links` ↔ 用過該外參的 `VT_episode_*` · `notes` 標 `in_article=true|false`  
5. **禁止**與 `3_citations` 混放 · P* 舊稿仍只入 `archive_P`

## 修改紀錄

- 2026-07-13 · zip next 5 · 零外參封板（用戶指令 next 5 · 延續早前 skip 決策）
