# pyramids_registry.csv · schema v0.1

> **藍圖** `tZpBp701` §5 · **slug** `pyramids-series`  
> **狀態** next 0 ✅ · header 寫死 · **禁止**在連結欄前插入新欄

---

## Header（#1–#16 · bit-identical）

```text
uuid,layer,item_type,subject_id,is_primary_shadow,p_path,m_path,view,name,series_seq,keywords,qutrit,vsm,topo_links,gravity_links,notes
```

## 欄位

| # | 欄 | 必填 | 說明 |
|---|-----|------|------|
| 1 | `uuid` | ✓ | `VT_{item_type}_{主體}[_{變體}]` · 全表唯一 |
| 2 | `layer` | ✓ | `实`｜`虚` |
| 3 | `item_type` | ✓ | 見下表 |
| 4 | `subject_id` | ✓ | 邏輯簇 · `VT_sub_*` |
| 5 | `is_primary_shadow` | ✓ | `true`｜`false` · 每 subject 一個 `true` |
| 6 | `p_path` | ○ | 交付檔 · episode → `1_articles/*.docx` |
| 7 | `m_path` | ✓ | `4_md/VT_*.md` |
| 8 | `view` | ✓ | snake_case |
| 9 | `name` | ✓ | 人讀標題 |
| 10 | `series_seq` | ○ | 1–4（实層 episode） |
| 11 | `keywords` | ○ | `\|` 分隔 |
| 12 | `qutrit` | ✓ | 六段 `0/1/2` · 跟 Spin Map metadata |
| 13 | `vsm` | ✓ | 9 位 `0`–`4` |
| 14 | `topo_links` | ○ | zip 內 uuid · `\|` · **雙向** |
| 15 | `gravity_links` | ○ | Spin Map 8 碼 · **單向** |
| 16 | `notes` | ○ | 厚內容路徑 · `原文✓` 等 |

## item_type

| layer | item_type | 厚內容櫃 |
|-------|-----------|----------|
| 实 | `episode` | `1_articles/` + `4_md/` |
| 虚 | `series_meta` | `2_craft/` |
| 虚 | `craft` | `2_craft/` |
| 虚 | `tool` | `2_craft/` |
| 虚 | `glossary` | `2_craft/` |
| 虚 | `citation` | `3_citations/`（厚）+ `4_md/` |
| 虚 | `external_youtube` | `5_external/` |
| 虚 | `external_web` | `5_external/` |
| 虚 | `external_article` | `5_external/` |
| 虚 | `external_fetch` | `5_external/` |
| 虚 | `script` | `6_py/` |

## 引述厚 MD（next 2）

`3_citations/*.md` **必須**含 `## 原文摘錄` · ≥1 段逐字引用（見 `WORKSPACE.md` · 藍圖 §8）。
