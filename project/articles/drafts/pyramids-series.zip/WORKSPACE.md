# pyramids-series · Topic Zip 工作區

> **slug** `pyramids-series` · **產品線** ② topics  
> **zip 施工** 0–9 ✅ · **收束 repair** next 6 ✅  
> **封包** [`pyramids-series.zip`](../pyramids-series.zip) · **施工驗收** [`6_py/ACCEPTANCE_next9.md`](6_py/ACCEPTANCE_next9.md) · **收束驗收** [`6_py/ACCEPTANCE_consolidate.md`](6_py/ACCEPTANCE_consolidate.md)  
> **藍圖**（P-agent12 · `tZpBp701`）：[`20260713_agent12_topic_zip_blueprint_v01_tZpBp701.md`](../../../ai-agent/agent-db/Project_Root/Physical_Reality/P-agent12_Other/20260713_agent12_topic_zip_blueprint_v01_tZpBp701.md)  
> **pipeline_stage**（系列）`awaiting_draft_confirm`  
> **參與** Agent 1–4（見藍圖 §14）

---

## 收束憲章（repair · CEO 定案）

**一句話**：**`{slug}.zip` = 工作區**；草稿區根目錄 **一 topic 只得一個 zip**，唔再平鋪散夾。

| 原則 | 說明 |
|------|------|
| **本体** | `pyramids-series.zip` 解壓後嘅目錄結構 = 全部資產 |
| **根目錄终局** | 只得 `pyramids-series.zip`（`repair next 4`） |
| **編輯模式 A** | 解壓 → `草稿區/pyramids-series/` → 改 → `qa_registry.py` → `package_zip.py` → **刪**解壓夾 |
| **禁止** | 長期並存 `workspace/` + 散夾 `01-`…`04-` + zip 三份正本 |
| **confirm ② 後** | 刪 zip（入 project DB · 藍圖 §2） |

**本夾** `pyramids-series/` = Mode A 解壓編輯夾 · 封包 `--clean` 後刪 · 根只得 zip。

日常三步：[`6_py/README.md`](6_py/README.md) · `unzip_work.py` → 改 → `package_zip.py --clean`

缺口表：[`6_py/GAP_INVENTORY.md`](6_py/GAP_INVENTORY.md)

---

## 收束批次（repair 0–6）

| 批 | 名稱 | 狀態 |
|----|------|------|
| **0** | 收束憲章 + 缺口表 | ✅ |
| **1** | zip 內容補全（en · work-paper · pipeline · sources） | ✅ |
| **2** | 正文 zh：`1_articles/ep0N_*.md` + 重打 docx | ✅ |
| **3** | registry／shadow 路徑對齊 | ✅ |
| **4** | 根目錄收束（刪 workspace + 散夾） | ✅ |
| **5** | 解壓／重封 SOP + 腳本 | ✅ |
| **6** | 收束驗收 | ✅ |

### 施工批次（zip 0–9 · 已完成）

| 批 | 名稱 | 狀態 |
|----|------|------|
| 0–9 | 憲章 → 驗收 | ✅ 見 [`6_py/ACCEPTANCE_next9.md`](6_py/ACCEPTANCE_next9.md) |

---

## 開工順序（zip 內）

1. **本檔** `WORKSPACE.md`
2. `2_csv/schema.md`
3. `pyramids_registry.csv`
4. 當批 repair 任務（見上表）
5. 批末 `6_py/qa_registry.py`

## 鐵律（VT-Z1～Z6）

- zip 內 uuid 只用 **`VT_*`** · **禁止** Spin Map 庫 uuid 作 zip `uuid`
- **`topo_links`** zip 內雙向 · **`gravity_links`** → Spin Map **單向** · **本 project 唔改 Spin Map DB**
- **一張** `pyramids_registry.csv`（虛實合一）
- 每 CSV 行 = 一個 `4_md/VT_*.md` shadow（必填）

## 目錄（zip 內 · 收束後目標）

```text
pyramids-series/                    # 解壓編輯時；封包後刪
├── WORKSPACE.md
├── pyramids_registry.csv
├── 1_articles/
│   ├── ep0N_{slug}.md              # repair 2 ✅
│   ├── ep0N_{slug}.docx
│   ├── en/ep0N_{slug}.md           # repair 1 ✅
├── 2_craft/
│   ├── work_papers/                # repair 1 ✅
│   ├── pipelines/                  # repair 1 ✅
│   └── sources/                    # repair 1 ✅
├── 3_citations/
├── 4_md/
├── 5_external/
└── 6_py/
```

## 封包

| 項 | 路徑 |
|----|------|
| zip（本体） | `草稿區/pyramids-series.zip` |
| 解壓 | `6_py/unzip_work.py` |
| QA | `6_py/qa_registry.py` |
| 打包 | `6_py/package_zip.py`（`--clean` = Mode A） |
| SOP | `6_py/README.md` |

## 與原草稿區

repair 4 後根目錄 **只得** `pyramids-series.zip` · 散夾 `01-`…`04-`／`workspace/` 已刪。

---

*repair next 0 封板 · 2026-07-13*
