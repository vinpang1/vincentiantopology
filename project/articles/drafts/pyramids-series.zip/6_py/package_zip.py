#!/usr/bin/env python3
"""package_zip.py · build {slug}.zip after QA PASS · optional --clean (Mode A)."""
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SLUG = "pyramids-series"
MARKER = "WORKSPACE.md"
QA = Path(__file__).resolve().parent / "qa_registry.py"
EXCLUDE_NAMES = {".DS_Store", ".gitkeep"}
EXCLUDE_SUFFIXES = {".pyc"}


def out_zip_path(root: Path) -> Path:
    """Zip lives beside extract dir: 草稿區/pyramids-series.zip."""
    if root.name == SLUG and (root / MARKER).is_file():
        return root.parent / f"{SLUG}.zip"
    return root.parent / f"{SLUG}.zip"


def qa_pass() -> bool:
    r = subprocess.run([sys.executable, str(QA)], cwd=ROOT, capture_output=True, text=True)
    print(r.stdout.strip())
    if r.stderr.strip():
        print(r.stderr.strip(), file=sys.stderr)
    return r.returncode == 0


def should_include(path: Path) -> bool:
    if path.name in EXCLUDE_NAMES:
        return False
    if path.suffix in EXCLUDE_SUFFIXES:
        return False
    if "__pycache__" in path.parts:
        return False
    return True


def build_zip(out_zip: Path) -> int:
    if out_zip.exists():
        out_zip.unlink()

    files: list[Path] = []
    for p in sorted(ROOT.rglob("*")):
        if p.is_file() and should_include(p):
            files.append(p)

    with zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for p in files:
            arc = p.relative_to(ROOT).as_posix()
            zf.write(p, arc)

    manifest = ROOT / "6_py" / "ZIP_MANIFEST.txt"
    manifest.write_text(
        "\n".join(
            [
                f"{SLUG}.zip",
                f"built: {datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}",
                f"files: {len(files)}",
                f"path: {out_zip}",
                f"qa: PASS (qa_registry.py)",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    size_kb = out_zip.stat().st_size // 1024
    print(f"zip: {out_zip} ({size_kb} KB, {len(files)} files)")
    return len(files)


def clean_extract(root: Path) -> None:
    if root.name != SLUG or not (root / MARKER).is_file():
        print(f"WARN: skip --clean (not {SLUG} workspace at {root})", file=sys.stderr)
        return
    parent = root.resolve().parent
    name = root.name
    os.chdir(parent)
    shutil.rmtree(name)
    print(f"clean: removed {name}/ — drafts root keeps {SLUG}.zip only")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--clean",
        action="store_true",
        help="after packaging, remove extract dir (Mode A)",
    )
    parser.add_argument(
        "--skip-qa",
        action="store_true",
        help="package without QA (debug only)",
    )
    args = parser.parse_args()

    out_zip = out_zip_path(ROOT)

    if not args.skip_qa and not qa_pass():
        print("ABORT: QA failed — fix before packaging", file=sys.stderr)
        return 1

    n = build_zip(out_zip)
    if n < 50:
        print(f"WARN: only {n} files in zip", file=sys.stderr)

    if args.clean:
        clean_extract(ROOT)

    return 0


if __name__ == "__main__":
    sys.exit(main())
