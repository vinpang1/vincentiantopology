#!/usr/bin/env python3
"""qa_registry.py · pyramids-series zip workspace (tZpBp701).

Usage:
  python3 qa_registry.py              # full verify; exit 0=PASS 1=FAIL
  python3 qa_registry.py --repair-topo  # symmetric-closure topo_links + sync shadows
  python3 qa_registry.py --report       # write 6_py/QA_REPORT.txt
"""
from __future__ import annotations

import argparse
import csv
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CSV_PATH = ROOT / "pyramids_registry.csv"
MD4 = ROOT / "4_md"
CIT = ROOT / "3_citations"
REPORT_PATH = Path(__file__).resolve().parent / "QA_REPORT.txt"

HEADER = (
    "uuid,layer,item_type,subject_id,is_primary_shadow,p_path,m_path,view,name,"
    "series_seq,keywords,qutrit,vsm,topo_links,gravity_links,notes"
)

VALID_LAYERS = {"实", "虚"}
VALID_ITEM_TYPES = {
    "episode",
    "series_meta",
    "craft",
    "tool",
    "glossary",
    "citation",
    "external_youtube",
    "external_web",
    "external_article",
    "external_fetch",
    "script",
}
LAYER_ITEM = {
    "实": {"episode"},
    "虚": VALID_ITEM_TYPES - {"episode"},
}

QUTRIT_RE = re.compile(r"^[012](/[012]){5}$")
VSM_RE = re.compile(r"^[0-4]{9}$")


def parse_links(raw: str) -> list[str]:
    return [p.strip() for p in raw.split("|") if p.strip()]


def join_links(links: list[str]) -> str:
    seen: list[str] = []
    for x in links:
        if x not in seen:
            seen.append(x)
    return "|".join(seen)


def load_rows() -> tuple[list[str], list[dict[str, str]]]:
    with CSV_PATH.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames
        assert fieldnames is not None
        return list(fieldnames), list(reader)


def save_rows(fieldnames: list[str], rows: list[dict[str, str]]) -> None:
    with CSV_PATH.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def sync_shadow_topo(uuid: str, topo: str) -> None:
    path = MD4 / f"{uuid}.md"
    if not path.exists():
        return
    text = path.read_text(encoding="utf-8")
    if "topo_links:" not in text:
        return
    replacement = f"topo_links: {topo}" if topo else 'topo_links: ""'
    text = re.sub(r"^topo_links:.*$", replacement, text, count=1, flags=re.MULTILINE)
    path.write_text(text, encoding="utf-8")


def repair_topo(rows: list[dict[str, str]]) -> int:
    by = {r["uuid"]: r for r in rows}
    fixes = 0
    for a, ra in by.items():
        for b in parse_links(ra["topo_links"]):
            if b not in by:
                continue
            rb = by[b]
            blinks = parse_links(rb["topo_links"])
            if a not in blinks:
                blinks.append(a)
                rb["topo_links"] = join_links(blinks)
                sync_shadow_topo(b, rb["topo_links"])
                fixes += 1
    return fixes


def check_topo(rows: list[dict[str, str]]) -> list[str]:
    by = {r["uuid"]: r for r in rows}
    errs: list[str] = []
    for a, ra in by.items():
        for b in parse_links(ra["topo_links"]):
            if b not in by:
                errs.append(f"topo: {a} → {b} (unknown uuid)")
            elif a not in parse_links(by[b]["topo_links"]):
                errs.append(f"topo: {a} → {b} (no reverse on {b})")
    return errs


def check_files(rows: list[dict[str, str]]) -> list[str]:
    errs: list[str] = []
    for r in rows:
        m = ROOT / r["m_path"]
        if not m.is_file():
            errs.append(f"file: missing m_path {r['uuid']} → {r['m_path']}")
        if r["p_path"]:
            p = ROOT / r["p_path"]
            if not p.is_file():
                errs.append(f"file: missing p_path {r['uuid']} → {r['p_path']}")
    return errs


def check_primary_shadow(rows: list[dict[str, str]]) -> list[str]:
    errs: list[str] = []
    primaries: dict[str, list[str]] = {}
    for r in rows:
        if r["is_primary_shadow"].lower() == "true":
            primaries.setdefault(r["subject_id"], []).append(r["uuid"])
    for sid, uuids in primaries.items():
        if len(uuids) != 1:
            errs.append(f"primary: subject_id {sid} has {len(uuids)} primaries: {uuids}")
    return errs


def check_gravity(rows: list[dict[str, str]]) -> list[str]:
    errs: list[str] = []
    for r in rows:
        g = r["gravity_links"].strip()
        if r["item_type"] == "citation" and not g:
            errs.append(f"gravity: citation {r['uuid']} missing gravity_links")
        if r["item_type"] != "citation" and g:
            errs.append(f"gravity: non-citation {r['uuid']} has gravity_links={g}")
        if g and not re.fullmatch(r"[A-Za-z0-9]{8}", g):
            errs.append(f"gravity: {r['uuid']} invalid gravity_links={g}")
    return errs


def check_uuids(rows: list[dict[str, str]]) -> list[str]:
    errs: list[str] = []
    seen: set[str] = set()
    for r in rows:
        u = r["uuid"]
        if u in seen:
            errs.append(f"uuid: duplicate {u}")
        seen.add(u)
        if not u.startswith("VT_"):
            errs.append(f"uuid: {u} does not start with VT_")
    return errs


def check_formats(rows: list[dict[str, str]]) -> list[str]:
    errs: list[str] = []
    for r in rows:
        q = r["qutrit"].strip()
        v = r["vsm"].strip()
        if not QUTRIT_RE.match(q):
            errs.append(f"format: {r['uuid']} bad qutrit={q!r}")
        if not VSM_RE.match(v):
            errs.append(f"format: {r['uuid']} bad vsm={v!r}")
        layer = r["layer"].strip()
        it = r["item_type"].strip()
        if layer not in VALID_LAYERS:
            errs.append(f"format: {r['uuid']} bad layer={layer!r}")
        if it not in VALID_ITEM_TYPES:
            errs.append(f"format: {r['uuid']} bad item_type={it!r}")
        elif layer in LAYER_ITEM and it not in LAYER_ITEM[layer]:
            errs.append(f"format: {r['uuid']} layer {layer} incompatible with item_type {it}")
        if r["is_primary_shadow"].lower() not in {"true", "false"}:
            errs.append(f"format: {r['uuid']} bad is_primary_shadow")
        expected_m = f"4_md/{r['uuid']}.md"
        if r["m_path"] != expected_m:
            errs.append(f"format: {r['uuid']} m_path should be {expected_m}")
    return errs


def check_episodes(rows: list[dict[str, str]]) -> list[str]:
    errs: list[str] = []
    eps = [r for r in rows if r["item_type"] == "episode"]
    if len(eps) != 4:
        errs.append(f"episode: expected 4 rows, got {len(eps)}")
    seqs = sorted(int(r["series_seq"]) for r in eps if r["series_seq"].isdigit())
    if seqs != [1, 2, 3, 4]:
        errs.append(f"episode: series_seq expected [1,2,3,4], got {seqs}")
    for r in eps:
        if not r["p_path"].endswith(".docx"):
            errs.append(f"episode: {r['uuid']} p_path not docx")
        if "docx" not in r["notes"] and "docx✓" not in r["notes"]:
            errs.append(f"episode: {r['uuid']} notes missing docx marker")
        for key in ("md源=", "en源=", "work_paper=", "pipeline=", "sources="):
            if key not in r["notes"]:
                errs.append(f"episode: {r['uuid']} notes missing {key.rstrip('=')}")
        md_match = re.search(r"md源=([^;]+)", r["notes"])
        if md_match:
            md_path = ROOT / md_match.group(1).strip()
            if not md_path.is_file():
                errs.append(f"episode: {r['uuid']} missing zh md {md_match.group(1)}")
    return errs


def thick_path_from_notes(notes: str) -> str | None:
    for part in notes.split(";"):
        part = part.strip()
        if part.startswith("厚文："):
            return part.replace("厚文：", "", 1).split("|")[0].strip()
    return None


def check_thick_content(rows: list[dict[str, str]]) -> list[str]:
    errs: list[str] = []
    for r in rows:
        if r["item_type"] in {"citation", "tool", "glossary", "series_meta"}:
            thick = thick_path_from_notes(r["notes"])
            if not thick:
                errs.append(f"thick: {r['uuid']} notes missing 厚文 path")
                continue
            for sub in thick.split("|"):
                sub = sub.strip()
                if sub and not (ROOT / sub).exists():
                    errs.append(f"thick: {r['uuid']} missing {sub}")
    return errs


def check_citation_excerpts() -> list[str]:
    errs: list[str] = []
    if not CIT.is_dir():
        return ["citation: missing 3_citations/"]
    for path in sorted(CIT.glob("*.md")):
        text = path.read_text(encoding="utf-8")
        if "## 原文摘錄" not in text:
            errs.append(f"citation: {path.name} missing ## 原文摘錄")
            continue
        idx = text.index("## 原文摘錄")
        body = text[idx:]
        if not re.search(r"^>\s+\S", body, re.MULTILINE):
            errs.append(f"citation: {path.name} 原文摘錄 has no blockquote excerpt")
    return errs


def check_workspace(rows: list[dict[str, str]]) -> list[str]:
    errs: list[str] = []
    ws = ROOT / "WORKSPACE.md"
    schema = ROOT / "2_csv" / "schema.md"
    for p in (ws, schema):
        if not p.is_file():
            errs.append(f"workspace: missing {p.name}")
    shadows = list(MD4.glob("VT_*.md"))
    if len(shadows) != len(rows):
        errs.append(f"workspace: 4_md shadows {len(shadows)} != csv rows {len(rows)}")
    return errs


def run_all_checks(rows: list[dict[str, str]]) -> list[str]:
    errs: list[str] = []
    errs.extend(check_uuids(rows))
    errs.extend(check_formats(rows))
    errs.extend(check_primary_shadow(rows))
    errs.extend(check_gravity(rows))
    errs.extend(check_episodes(rows))
    errs.extend(check_files(rows))
    errs.extend(check_thick_content(rows))
    errs.extend(check_citation_excerpts())
    errs.extend(check_topo(rows))
    errs.extend(check_workspace(rows))
    return errs


def write_report(rows: list[dict[str, str]], errs: list[str], repaired: int | None) -> None:
    lines = [
        "pyramids-series · qa_registry.py",
        f"rows: {len(rows)}",
        f"result: {'PASS' if not errs else 'FAIL'}",
    ]
    if repaired is not None:
        lines.append(f"repair-topo: {repaired} fix(es)")
    if errs:
        lines.extend(["", "issues:"])
        lines.extend(f"  · {e}" for e in errs)
    else:
        lines.extend(
            [
                "",
                "checks: uuid · format · primary · gravity · episodes · files",
                "        thick · citation excerpts · topo · workspace",
            ]
        )
    REPORT_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repair-topo", action="store_true")
    parser.add_argument("--report", action="store_true", help="write 6_py/QA_REPORT.txt")
    args = parser.parse_args()

    fieldnames, rows = load_rows()
    if ",".join(fieldnames) != HEADER:
        print("FAIL: CSV header drift", file=sys.stderr)
        return 1

    repaired: int | None = None
    if args.repair_topo:
        repaired = repair_topo(rows)
        save_rows(fieldnames, rows)
        print(f"repair-topo: {repaired} reverse link(s) added")

    all_errs = run_all_checks(rows)

    if args.report or not all_errs:
        write_report(rows, all_errs, repaired)

    if all_errs:
        print(f"FAIL: {len(all_errs)} issue(s)")
        for e in all_errs:
            print(f"  · {e}")
        return 1

    print(
        f"PASS: {len(rows)} rows · topo · gravity · excerpts · thick paths · episodes"
    )
    if args.report:
        print(f"report: {REPORT_PATH}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
