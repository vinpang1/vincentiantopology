# topo 雙向稽核 · next 6

> **日期** 2026-07-13 · **工具** `6_py/qa_registry.py --repair-topo`

## 修復

| 缺失反向邊 | 修復 |
|------------|------|
| `VT_series_plan` → `VT_episode_ep01..04` | 四期 episode 補 `VT_series_plan` |

共 **4** 條反向邊已寫入 CSV + `4_md` shadow YAML。

## 驗收（`qa_registry.py`）

| 檢查 | 結果 |
|------|------|
| CSV header 16 欄 | PASS |
| `VT_*` uuid 唯一 | PASS（22 行） |
| 每 `subject_id` 一個 `is_primary_shadow: true` | PASS |
| `citation` 必有 `gravity_links` · 非 citation 必空 | PASS |
| 全部 `m_path` 存在 · episode `p_path` docx 存在 | PASS |
| `topo_links` zip 內雙向 | PASS |

## 刻意無連結（可選引述 · 未入出街索引）

| uuid | 說明 |
|------|------|
| `VT_citation_gO5inxjd` | Ep1 可選 · 無 episode topo |
| `VT_citation_W7F7GRGQ` | Ep2 對照用 · 只連 `SL9cxP8Y` |
| `VT_citation_bbh1gjCw` | Ep2 可選 |
| `VT_citation_ky7XuH3B` | Ep2 可選 |

## 圖式（修復後）

```text
VT_series_plan ↔ tools(4) + glossary + episodes(4)
VT_episode_epNN ↔ tool_NN + citations（出街 4 條）
VT_citation_SL9cxP8Y ↔ VT_citation_W7F7GRGQ
VT_citation_kR3mNpW8 ↔ VT_citation_vT2xQmL5
```

*next 6 封板 · 零外參 batch 5 不影響 topo*
