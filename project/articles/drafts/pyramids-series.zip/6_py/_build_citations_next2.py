#!/usr/bin/env python3
"""One-off: zip next 2 citations batch. Not qa_registry (next 7)."""
from __future__ import annotations

import csv
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CIT = ROOT / "3_citations"
ARCH = CIT / "archive_P"
MD4 = ROOT / "4_md"
CSV = ROOT / "pyramids_registry.csv"
DRAFTS = ROOT.parent

CITATIONS: list[dict] = [
    {
        "sm": "nk8jIIvx",
        "file": "nk8jIIvx_petrie_ten_years.md",
        "view": "citation_petrie",
        "name": "Petrie · Ten years' digging",
        "author": "Flinders Petrie",
        "title": "Ten years' digging in Egypt, 1881–1891",
        "tier": "T3",
        "eps": "ep1|ep3|ep4",
        "qutrit": "1/1/1/0/1/1",
        "vsm": "211320100",
        "excerpt": (
            "I found repeatedly that the hard stones, basalt, granite, and diorite, were sawn; "
            "and that the saw was not a blade, or wire, used with a hard powder, but was set "
            "with fixed cutting points, in fact, a jewelled saw. These saws must have been as "
            "much as nine feet in length, as the cuts run lengthwise on the sarcophagi.\n\n"
            "one of the most usual tools was the tubular drill, and this was also set with "
            "fixed cutting points; I have a core from inside a drill hole, broken away in the "
            "working, which shows the spiral grooves produced by the cutting points as they "
            "sunk down into the material"
        ),
        "anchor": "Ch.I Gizeh · tools · sarcophagus workmanship",
        "spin_p": "Physical_Reality/B03_History_Culture/20260610_ten_years_digging_in_egypt_1881_1891_nk8jIIvx.txt",
    },
    {
        "sm": "sOr3Lhqe",
        "file": "sOr3Lhqe_rawlinson_ancient_egypt.md",
        "view": "citation_rawlinson",
        "name": "Rawlinson · Ancient Egypt",
        "author": "George Rawlinson",
        "title": "Ancient Egypt",
        "tier": "T3",
        "eps": "ep1|ep2|ep3|ep4",
        "qutrit": "1/1/1/0/1/1",
        "vsm": "211320100",
        "excerpt": (
            "The fashion of burying in pyramids continued to the close of Manetho's sixth dynasty, "
            "but no later monarchs rivalled the great works of Khufu and Shafra. The tombs of their "
            "successors were monuments of a moderate size, involving no oppression of the people, "
            "but perhaps rather improving their condition by causing a rise in the rate of wages."
        ),
        "anchor": "Pyramid builders · royal tombs at Gizeh",
        "spin_p": "Physical_Reality/B03_History_Culture/20260610_ancient_egypt_sOr3Lhqe.txt",
    },
    {
        "sm": "2MshQLAD",
        "file": "2MshQLAD_burr_pyramids.md",
        "view": "citation_burr",
        "name": "Burr · Pyramids (Ch.6)",
        "author": "Burr",
        "title": "Ancient and modern engineering and the Isthmian canal",
        "tier": "T3",
        "eps": "ep1|ep3",
        "qutrit": "1/1/1/1/1/1",
        "vsm": "212210000",
        "excerpt": (
            "The Great Pyramid has a square base, which was originally 764 feet on a side, with a "
            "height of apex above the surface of the ground of over 480 feet. This great mass of "
            "masonry contains about 3,500,000 cubic yards and weighs nearly 7,000,000 tons.\n\n"
            "The Greek historian Herodotus states that its construction required the labor of "
            "100,000 men for twenty years. An enormous quantity of granite was required to be "
            "transported about 500 miles down the Nile from the quarries at Syene."
        ),
        "anchor": "Ch.6 The Pyramids · volume · granite haul",
        "spin_p": "Physical_Reality/B11_Engineering_Design/20260604_ancient_and_modern_engineering_and_the_ist_2MshQLAD.txt",
    },
    {
        "sm": "phVXjCiA",
        "file": "phVXjCiA_herodotus_egypt.md",
        "view": "citation_herodotus",
        "name": "希羅多德 · An Account of Egypt",
        "author": "Herodotus",
        "title": "An Account of Egypt (Histories, Book II)",
        "tier": "T3",
        "eps": "ep1|ep3|ep4",
        "qutrit": "1/1/1/0/1/1",
        "vsm": "212210110",
        "excerpt": (
            "they worked by a hundred thousand men at a time, for each three months continually. "
            "Of this oppression there passed ten years while the causeway was made by which they "
            "drew the stones, which causeway they built, and it is a work not much less, as it "
            "appears to me, than the pyramid; for the length of it is five furlongs and the "
            "breadth ten fathoms and the height, where it is highest, eight fathoms\n\n"
            "For the making of the pyramid itself there passed a period of twenty years"
        ),
        "anchor": "Cheops · causeway · labour rotation",
        "spin_p": "Physical_Reality/B03_History_Culture/20260603_an_account_of_egypt_phVXjCiA.txt",
    },
    {
        "sm": "gO5inxjd",
        "file": "gO5inxjd_maspero_corvee.md",
        "view": "citation_maspero",
        "name": "Maspero · History of Egypt (Vol.2)",
        "author": "Gaston Maspero",
        "title": "History of Egypt, Chaldæa, Syria, Babylonia, and Assyria (Vol. 2)",
        "tier": "T3",
        "eps": "ep1",
        "qutrit": "1/1/1/0/1/1",
        "vsm": "211320100",
        "excerpt": (
            "What the collection of the taxes had begun was almost always brought to a climax by "
            "the _corvées_. However numerous the royal and seignorial slaves might have been, "
            "they were insufficient for the cultivation of all the lands of the domains, and a "
            "part of Egypt must always have lain fallow, had not the number of workers been "
            "augmented by the addition of those who were in the position of freemen."
        ),
        "anchor": "Rural corvée · labour background (optional ep1)",
        "spin_p": "Physical_Reality/B03_History_Culture/20260603_history_of_egypt_chald_a_syria_babylonia_a_gO5inxjd.txt",
    },
    {
        "sm": "SL9cxP8Y",
        "file": "SL9cxP8Y_eberhard_china_3d.md",
        "view": "citation_eberhard_3d",
        "name": "Eberhard · A history of China (3d ed.)",
        "author": "Wolfram Eberhard",
        "title": "A history of China, 3d ed. rev. and enl.",
        "tier": "T3",
        "eps": "ep2",
        "qutrit": "1/1/1/0/1/1",
        "vsm": "211320100",
        "topo_extra": "VT_citation_W7F7GRGQ",
        "excerpt": (
            "About 1600 B.C. we come at last into the realm of history. Of the Shang dynasty, "
            "which now followed, we have knowledge both from later texts and from excavations "
            "and the documents they have brought to light. The Shang civilization, an evident "
            "off-shoot of the Lung-shan culture (Tai, Yao, and Tunguses), but also with elements "
            "of the Hsia culture (with Tibetan and Mongol and/or Turkish elements), was beyond "
            "doubt a high civilization."
        ),
        "anchor": "Ch.I PREHISTORY · Ch.II SHANG",
        "spin_p": "Physical_Reality/B03_History_Culture/20260603_a_history_of_china_3d_ed_rev_and_enl_SL9cxP8Y.txt",
    },
    {
        "sm": "W7F7GRGQ",
        "file": "W7F7GRGQ_eberhard_china_1st.md",
        "view": "citation_eberhard_1st",
        "name": "Eberhard · A History of China (Gutenberg 11367)",
        "author": "Wolfram Eberhard",
        "title": "A History of China (1st ed. · Gutenberg #11367)",
        "tier": "T3",
        "eps": "ep2",
        "qutrit": "1/1/1/0/1/1",
        "vsm": "211320100",
        "topo_extra": "VT_citation_SL9cxP8Y",
        "excerpt": (
            "About 1600 B.C. we come at last into the realm of history. Of the Shang dynasty, "
            "which now followed, we have knowledge both from later texts and from excavations "
            "and the documents they have brought to light."
        ),
        "anchor": "Ch.I PREHISTORY（對照 3d ed.）",
        "spin_p": "Physical_Reality/B03_History_Culture/20260627_a_history_of_china_eberhard_W7F7GRGQ.txt",
    },
    {
        "sm": "kR3mNpW8",
        "file": "kR3mNpW8_erlitou_statistical.md",
        "view": "citation_erlitou_stat",
        "name": "Erlitou statistical chronology (T2)",
        "author": "Revista, Zen et al.",
        "title": "Statistical Chronology of Erlitou: Constraining the Xia Dynasty's Origins",
        "tier": "T2",
        "eps": "ep2",
        "qutrit": "1/2/1/0/2/2",
        "vsm": "001130100",
        "topo_extra": "VT_citation_vT2xQmL5",
        "excerpt": (
            "This paper addresses these uncertainties by applying advanced statistical chronological "
            "modeling techniques, specifically Bayesian analysis, to a comprehensive dataset of "
            "radiocarbon dates from the Erlitou type site and associated cultural manifestations. "
            "By integrating these dates with archaeological stratigraphy and cultural phasing, we "
            "aim to produce a high-resolution chronological framework for Erlitou."
        ),
        "anchor": "Abstract · Bayesian radiocarbon modeling",
        "spin_p": "Physical_Reality/B03_History_Culture/20260627_erlitou_statistical_chronology_kR3mNpW8.bin",
    },
    {
        "sm": "vT2xQmL5",
        "file": "vT2xQmL5_china_radiocarbon_databank.md",
        "view": "citation_china_c14",
        "name": "Qiu et al. · China radiocarbon databank (T2)",
        "author": "Menghan Qiu; Linyao Du; Richard Staff; et al.",
        "title": "Chronology of early China: A radiocarbon databank for Chinese archaeology",
        "tier": "T2",
        "eps": "ep2",
        "qutrit": "1/2/1/0/2/2",
        "vsm": "001130100",
        "topo_extra": "VT_citation_kR3mNpW8",
        "excerpt": (
            "Archaeological Information\n"
            "Radiocarbon Information\n"
            "Site Name · Byname · Chinese Name · Category · Era · Comment\n"
            "Region · Province · Prefecture · County\n"
            "Longitude (°E) · Latitude (°N) · Elevation (m)\n"
            "Dating Material · Technique · Uncertainty (yr) · Median (cal BP) · σ (yr)"
        ),
        "anchor": "v2023.4 databank column schema（xlsx 正本）",
        "spin_p": "Physical_Reality/B03_History_Culture/20260627_china_radiocarbon_databank_202_vT2xQmL5.bin",
    },
    {
        "sm": "kR7mNpQx",
        "file": "kR7mNpQx_frazer_golden_bough_vol06.md",
        "view": "citation_frazer",
        "name": "Frazer · The Golden Bough (Vol. 06)",
        "author": "James Frazer",
        "title": "The Golden Bough: A Study in Magic and Religion (Vol. 06 of 12)",
        "tier": "T3",
        "eps": "ep4",
        "qutrit": "1/1/0/0/1/1",
        "vsm": "000000000",
        "excerpt": (
            "Reigning as a king on earth, Osiris reclaimed the Egyptians from savagery, gave them "
            "laws, and taught them to worship the gods. Before his time the Egyptians had been "
            "cannibals. But Isis, the sister and wife of Osiris, discovered wheat and barley "
            "growing wild, and Osiris introduced the cultivation of these grains amongst his "
            "people, who forthwith abandoned cannibalism and took kindly to a corn diet."
        ),
        "anchor": "Part IV Adonis Attis Osiris · myth of kingship",
        "spin_p": "Physical_Reality/B01_Humanities/20260622_the_golden_bough_vol_06_kR7mNpQx.txt",
    },
    {
        "sm": "bbh1gjCw",
        "file": "bbh1gjCw_giles_china_greek.md",
        "view": "citation_giles",
        "name": "Giles · China and the Chinese",
        "author": "Herbert A. Giles",
        "title": "China and the Chinese",
        "tier": "T3",
        "eps": "ep2",
        "qutrit": "1/1/1/0/1/1",
        "vsm": "211320100",
        "excerpt": (
            "The study of Chinese presents at least one advantage over the study of the Greek and "
            "Roman classics; I might add, of Hebrew, of Syriac, and even of Sanskrit. It may be "
            "pursued for two distinct objects. The first, and most important object to many, is "
            "to acquire a practical acquaintance with a _living_ language, spoken and written by "
            "about one-third of the existing population of the earth"
        ),
        "anchor": "Lecture IV · China and Ancient Greece（可選對照）",
        "spin_p": "Physical_Reality/B01_Humanities/20260605_china_and_the_chinese_bbh1gjCw.txt",
    },
    {
        "sm": "ky7XuH3B",
        "file": "ky7XuH3B_baikie_peeps_egypt.md",
        "view": "citation_baikie",
        "name": "Baikie · Peeps at Many Lands: Ancient Egypt",
        "author": "James Baikie",
        "title": "Peeps at Many Lands: Ancient Egypt",
        "tier": "T3",
        "eps": "ep2",
        "qutrit": "1/1/1/0/1/1",
        "vsm": "211320100",
        "excerpt": (
            "The Pyramids, for instance, those huge piles that are still the wonder of the world, "
            "were far older than any building now standing in Europe, before Joseph was sold to "
            "be a slave in Potiphar's house. Hundreds upon hundreds of years before anyone had "
            "ever heard of the Greeks and the Romans, there were great Kings reigning in Egypt"
        ),
        "anchor": "Popular chronology tone（可選）",
        "spin_p": "Physical_Reality/B03_History_Culture/20260603_peeps_at_many_lands_ancient_egypt_ky7XuH3B.txt",
    },
]

P_ARCHIVE = [
    ("Zs6DCH68", "01-pyramid-construction-archaeology/20260610_pyramid_construction_archaeology_Zs6DCH68.txt", "ep1 舊稿改寫源"),
    ("HOEs1amN", "03-pyramid-alien-claim-critique/20260610_pyramid_alien_claim_critique_HOEs1amN.txt", "ep3 舊稿改寫源"),
    ("SbcAo2im", "02-pyramid-china-chronology/20260610_pyramid_china_chronology_SbcAo2im.txt", "ep2 舊稿改寫源"),
    ("FPIYc3RZ", "04-pyramid-reading-method/20260610_pyramid_conspiracy_narrative_FPIYc3RZ.txt", "ep4 舊稿改寫源（superseded by v2）"),
]


def thick_md(c: dict) -> str:
    eps = c["eps"].replace("|", " · ")
    return f"""# {c['name']}

> Spin Map B/A · `gravity_links: {c['sm']}` · **只讀** · 梯隊 {c['tier']}  
> 系列 `pyramids` · 用於 {eps}

## 書目

| 欄 | 內容 |
|----|------|
| 作者 | {c['author']} |
| 書名 | *{c['title']}* |
| Spin Map `p_path` | `{c['spin_p']}` |
| 章／錨 | {c['anchor']} |

## 系列用途

用於：{eps} · 見各 slug `sources.md` 書名鎖定表

## 原文摘錄

> {c['excerpt'].replace(chr(10), chr(10) + '> ')}

*來源：Spin Map Physical_Reality 正本（只讀抽取）· zip next 2*

## 修改紀錄

- 2026-07-13 · zip next 2 · 厚引述入 `3_citations/`
"""


def shadow_md(c: dict) -> str:
    topo = c.get("topo_extra", "")
    topo_line = f"topo_links: {topo}" if topo else 'topo_links: ""'
    return f"""---
uuid: VT_citation_{c['sm']}
subject_id: VT_sub_citation_{c['sm']}
item_type: citation
layer: 虚
is_primary_shadow: true
m_path: 4_md/VT_citation_{c['sm']}.md
view: {c['view']}
name: {c['name']}
keywords: pyramids|citation|{c['sm']}
qutrit: "{c['qutrit']}"
vsm: "{c['vsm']}"
{topo_line}
gravity_links: {c['sm']}
---

# doc_summary

{c['author']} · {c['title']}。厚文：`3_citations/{c['file']}` · 原文✓ · ep link next 3
"""


def csv_row(c: dict) -> dict:
    topo = c.get("topo_extra", "")
    notes = f"厚文：3_citations/{c['file']};原文✓;ep link next 3;eps={c['eps']}"
    return {
        "uuid": f"VT_citation_{c['sm']}",
        "layer": "虚",
        "item_type": "citation",
        "subject_id": f"VT_sub_citation_{c['sm']}",
        "is_primary_shadow": "true",
        "p_path": "",
        "m_path": f"4_md/VT_citation_{c['sm']}.md",
        "view": c["view"],
        "name": c["name"],
        "series_seq": "",
        "keywords": f"pyramids|citation|{c['sm']}",
        "qutrit": c["qutrit"],
        "vsm": c["vsm"],
        "topo_links": topo,
        "gravity_links": c["sm"],
        "notes": notes,
    }


def main() -> None:
    CIT.mkdir(parents=True, exist_ok=True)
    ARCH.mkdir(parents=True, exist_ok=True)
    MD4.mkdir(parents=True, exist_ok=True)

    for c in CITATIONS:
        (CIT / c["file"]).write_text(thick_md(c), encoding="utf-8")
        (MD4 / f"VT_citation_{c['sm']}.md").write_text(shadow_md(c), encoding="utf-8")

    for sm, rel, note in P_ARCHIVE:
        src = DRAFTS / rel
        dst = ARCH / f"{sm}_archive_stub.md"
        body = src.read_text(encoding="utf-8") if src.exists() else f"（原稿缺失：{rel}）"
        dst.write_text(
            f"# P* 舊稿封存 · `{sm}`\n\n"
            f"> **禁止** `gravity_links` · **禁止** copy 入正文 · {note}\n\n"
            f"原路徑：`草稿區/{rel}`\n\n"
            f"## 原文摘錄（自產舊稿 · 非 Spin Map B/A）\n\n"
            f"> {body[:400].replace(chr(10), chr(10) + '> ')}\n\n"
            f"*zip next 2 · archive_P only*\n",
            encoding="utf-8",
        )
        if src.exists():
            shutil.copy2(src, ARCH / src.name)

    existing: list[dict] = []
    with CSV.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames
        assert fieldnames
        for row in reader:
            if not row["uuid"].startswith("VT_citation_"):
                existing.append(row)

    new_rows = [csv_row(c) for c in CITATIONS]
    with CSV.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(existing)
        writer.writerows(new_rows)

    print(f"Wrote {len(CITATIONS)} citations + {len(P_ARCHIVE)} P* archive stubs")


if __name__ == "__main__":
    main()
