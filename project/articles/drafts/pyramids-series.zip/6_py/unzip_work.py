#!/usr/bin/env python3
"""unzip_work.py · repair next 5 · Mode A: extract {slug}.zip for editing."""
from __future__ import annotations

import argparse
import shutil
import sys
import zipfile
from pathlib import Path

SLUG = "pyramids-series"
MARKER = "WORKSPACE.md"


def resolve_defaults(script: Path) -> tuple[Path, Path]:
    """Return (drafts_root, extract_dir) from script location or cwd."""
    work = script.parents[1]
    if work.name == SLUG and (work / MARKER).is_file():
        drafts = work.parent
        return drafts, drafts / SLUG

    cwd = Path.cwd()
    if (cwd / f"{SLUG}.zip").is_file():
        return cwd, cwd / SLUG
    if cwd.name == SLUG and (cwd / MARKER).is_file():
        return cwd.parent, cwd
    if (cwd.parent / f"{SLUG}.zip").is_file():
        return cwd.parent, cwd.parent / SLUG
    return cwd, cwd / SLUG


def extract(zip_path: Path, dest: Path, *, force: bool) -> int:
    if not zip_path.is_file():
        print(f"ABORT: missing zip {zip_path}", file=sys.stderr)
        return 1

    if dest.exists() and (dest / MARKER).is_file():
        if force:
            shutil.rmtree(dest)
        else:
            print(f"OK: already extracted at {dest}")
            print("edit → python3 6_py/qa_registry.py → python3 6_py/package_zip.py --clean")
            return 0

    if dest.exists() and force:
        shutil.rmtree(dest)

    if dest.exists():
        print(f"ABORT: {dest} exists (use --force to replace)", file=sys.stderr)
        return 1

    dest.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "r") as zf:
        zf.extractall(dest)

    n = sum(1 for p in dest.rglob("*") if p.is_file())
    print(f"extract: {zip_path.name} → {dest}/ ({n} files)")
    print("next: edit → python3 6_py/qa_registry.py → python3 6_py/package_zip.py --clean")
    return 0


def main() -> int:
    script = Path(__file__).resolve()
    drafts, default_dest = resolve_defaults(script)
    default_zip = drafts / f"{SLUG}.zip"

    parser = argparse.ArgumentParser(description=f"Extract {SLUG}.zip for Mode A editing")
    parser.add_argument("--zip", type=Path, default=default_zip, help="path to zip")
    parser.add_argument("--dest", type=Path, default=default_dest, help="extract directory")
    parser.add_argument("--force", action="store_true", help="replace existing extract")
    args = parser.parse_args()

    return extract(args.zip.resolve(), args.dest.resolve(), force=args.force)


if __name__ == "__main__":
    sys.exit(main())
