# 收束驗收 · repair next 6 · pyramids-series

> **藍圖** `tZpBp701` §0–§1 · **日期** 2026-07-13  
> **pipeline_stage** `awaiting_draft_confirm`（zip 收束完成 · **未** confirm ①②③）  
> **區分**：施工驗收見 [`ACCEPTANCE_next9.md`](ACCEPTANCE_next9.md) · 本檔 = **收束 repair 0–6**

---

## 收束目標（CEO 定案）

> **草稿區根目錄：一 topic 只得 `pyramids-series.zip`；zip 內 = 完整工作區。**

| 檢查 | 結果 | 證據 |
|------|------|------|
| 根目錄只得 zip（+ `.gitkeep`） | **PASS** | 無 `workspace/` · 無 `01-`…`04-` · 無 `pyramids-series/` 解壓夾（封包後） |
| zip 解壓後 `qa_registry.py` | **PASS** | exit 0 · `QA_REPORT.txt` |
| zip 內容自洽（不依散夾） | **PASS** | registry／shadow 全 zip 内路径 |

---

## repair 0–6 簽收

| 批 | 名稱 | 結果 | 證據 |
|----|------|------|------|
| **0** | 收束憲章 + 缺口表 | **PASS** | `WORKSPACE.md` · `GAP_INVENTORY.md` |
| **1** | en · work-paper · pipeline · sources 入 zip | **PASS** | `1_articles/en/` ×4 · `2_craft/work_papers/` ×4 · `pipelines/` ×4 · `sources/` ×4 |
| **2** | zh md + docx 源對齊 | **PASS** | `1_articles/ep0N_*.md` + `.docx` · `md_to_docx.py` |
| **3** | registry／shadow 路徑 | **PASS** | `repair_next3.py` · episode `notes` · citation topo |
| **4** | 根目錄收束 | **PASS** | 散夾已刪 · zip 重打 |
| **5** | Mode A SOP | **PASS** | `unzip_work.py` · `package_zip.py --clean` · `6_py/README.md` |
| **6** | 收束驗收 | **PASS** | 本檔 |

---

## zip 內容核對（next 6）

| 類別 | 預期 | 實測 |
|------|------|------|
| registry 行 | 22 | 22 |
| episode（实） | 4 | 4 · `series_seq` 1–4 |
| zh 正文 md | 4 | `1_articles/ep01–04_*.md` |
| en 正文 md | 4 | `1_articles/en/ep01–04_*.md` |
| docx | 4 | `1_articles/ep01–04_*.docx` |
| work_papers | 4 | `2_craft/work_papers/` |
| pipelines | 4 | `2_craft/pipelines/` |
| sources | 4 | `2_craft/sources/` |
| citation 厚 MD + 原文摘錄 | 12 | 12/12 `## 原文摘錄` |
| shadow | 22 | `4_md/VT_*.md` |
| 外參 | 0 | `5_external/README.md` only |

---

## Mode A 工作流（驗收試跑）

```bash
cd 草稿區
unzip -q pyramids-series.zip -d pyramids-series
cd pyramids-series
python3 6_py/qa_registry.py          # PASS
python3 6_py/package_zip.py --clean  # 重打 zip · 刪解壓夾
```

**試跑** 2026-07-13：**PASS**（repair next 5 · next 6 複核）

---

## 統計（收束後）

```text
registry rows:     22
zip files:         92（含本驗收檔）
zip size:          ~278 KB
drafts root:       pyramids-series.zip only
pipeline_stage:    awaiting_draft_confirm（四期 episode）
```

---

## 相對施工驗收（next 9）之變更

| 項 | next 9 時 | 收束後 |
|----|-----------|--------|
| 根目錄 | zip + workspace + 散夾 | **只得 zip** |
| 正文源 | `草稿區/01-…/article.md` | `1_articles/ep0N_*.md` |
| craft 副檔 | 散夾 only | zip 内 `2_craft/` |
| citation `gO5inxjd` 等 | 未連 episode | **已 topo**（repair 3） |
| 日常改文 | 開散夾 | **Mode A** 解壓 zip |

---

## 未做（等人工關卡）

- **confirm ①** → 改 zip 内 `1_articles/*.md` → `@agent-02-edit`
- **confirm ②** → 入 project DB · **刪** `pyramids-series.zip`
- **confirm ③** → `@agent-03-ops` export

**禁止**（本收束未觸及）：改 Spin Map DB · 改 AGENTS／Cursor rules · 入 project DB

---

*收束 repair 0–6 封板 · 2026-07-13*
