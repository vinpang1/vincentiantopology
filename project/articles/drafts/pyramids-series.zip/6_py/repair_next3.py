#!/usr/bin/env python3
"""repair next 3: align pyramids_registry.csv + 4_md shadows to zip-internal paths."""
from __future__ import annotations

import csv
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CSV_PATH = ROOT / "pyramids_registry.csv"
MD4 = ROOT / "4_md"
QA = Path(__file__).resolve().parent / "qa_registry.py"

EPISODES = [
    (1, "pyramid-construction-archaeology"),
    (2, "pyramid-china-chronology"),
    (3, "pyramid-alien-claim-critique"),
    (4, "pyramid-reading-method"),
]

# citation uuid → episode uuid (pending ep link next 3)
CITATION_EP_LINKS: dict[str, str] = {
    "VT_citation_gO5inxjd": "VT_episode_ep01",
    "VT_citation_W7F7GRGQ": "VT_episode_ep02",
    "VT_citation_bbh1gjCw": "VT_episode_ep02",
    "VT_citation_ky7XuH3B": "VT_episode_ep02",
}

TOOL_SOURCE_REPLACEMENTS = [
    (
        ROOT / "2_craft/tool_evidence_grid.md",
        "`01-pyramid-construction-archaeology/work-paper.md`",
        "`2_craft/work_papers/ep01_pyramid-construction-archaeology.md`",
    ),
    (
        ROOT / "2_craft/tool_china_egypt_axes.md",
        "`02-pyramid-china-chronology/work-paper.md`",
        "`2_craft/work_papers/ep02_pyramid-china-chronology.md`",
    ),
    (
        ROOT / "2_craft/tool_alien_three_gates.md",
        "`03-pyramid-alien-claim-critique/work-paper.md`",
        "`2_craft/work_papers/ep03_pyramid-alien-claim-critique.md`",
    ),
    (
        ROOT / "2_craft/tool_method_seven.md",
        "`04-pyramid-reading-method/article.md` §總結 · `work-paper.md`",
        "`1_articles/ep04_pyramid-reading-method.md` §總結 · `2_craft/work_papers/ep04_pyramid-reading-method.md`",
    ),
]


def episode_stem(seq: int, slug: str) -> str:
    return f"ep{seq:02d}_{slug}"


def episode_paths(seq: int, slug: str) -> dict[str, str]:
    stem = episode_stem(seq, slug)
    return {
        "md": f"1_articles/{stem}.md",
        "docx": f"1_articles/{stem}.docx",
        "en": f"1_articles/en/{stem}.md",
        "work_paper": f"2_craft/work_papers/{stem}.md",
        "pipeline": f"2_craft/pipelines/{stem}.md",
        "sources": f"2_craft/sources/{stem}.md",
    }


def parse_links(raw: str) -> list[str]:
    return [p.strip() for p in raw.split("|") if p.strip()]


def join_links(links: list[str]) -> str:
    seen: list[str] = []
    for x in links:
        if x not in seen:
            seen.append(x)
    return "|".join(seen)


def sync_shadow_topo(uuid: str, topo: str) -> None:
    path = MD4 / f"{uuid}.md"
    if not path.exists():
        return
    text = path.read_text(encoding="utf-8")
    replacement = f"topo_links: {topo}" if topo else 'topo_links: ""'
    text = re.sub(r"^topo_links:.*$", replacement, text, count=1, flags=re.MULTILINE)
    path.write_text(text, encoding="utf-8")


def build_episode_notes(seq: int, slug: str) -> str:
    p = episode_paths(seq, slug)
    return (
        f"stage=awaiting_draft_confirm;slug={slug};"
        f"md源={p['md']};en源={p['en']};"
        f"work_paper={p['work_paper']};pipeline={p['pipeline']};sources={p['sources']};docx✓"
    )


def patch_episode_shadow(seq: int, slug: str) -> None:
    p = episode_paths(seq, slug)
    path = MD4 / f"VT_episode_ep{seq:02d}.md"
    text = path.read_text(encoding="utf-8")
    summary = (
        f"**slug** `{slug}` · **pipeline_stage** `awaiting_draft_confirm` · "
        f"正文：`{p['md']}` · en：`{p['en']}` · "
        f"craft：`{p['work_paper']}` · docx✓"
    )
    text = re.sub(
        r"\*\*slug\*\* `[^`]+` · \*\*pipeline_stage\*\* `[^`]+` · 正文源：`[^`]+` · docx✓",
        summary,
        text,
    )
    if "repair next 3" not in text:
        text = text.replace(
            "- 2026-07-13 · repair next 2 · zh md 源入 1_articles/",
            "- 2026-07-13 · repair next 2 · zh md 源入 1_articles/\n"
            "- 2026-07-13 · repair next 3 · registry／shadow zip 内路径",
        )
    path.write_text(text, encoding="utf-8")


def clean_citation_notes(notes: str, ep_num: int) -> str:
    ep_label = f"ep{ep_num}"
    notes = re.sub(r";?ep link next 3", "", notes)
    notes = re.sub(r";?ep\d{2} linked", "", notes)
    notes = re.sub(rf";?eps={ep_label}(?:\|[^\;]+)?", "", notes)
    notes = re.sub(rf";?{ep_label} linked", "", notes)
    notes = f"{notes};{ep_label} linked".lstrip(";")
    return notes


def patch_citation_shadow(uuid: str, ep_uuid: str) -> None:
    ep_n = ep_uuid.replace("VT_episode_ep", "")
    path = MD4 / f"{uuid}.md"
    text = path.read_text(encoding="utf-8")
    if "repair next 3" not in text:
        text = text.rstrip() + f"\n\n- 2026-07-13 · repair next 3 · topo → {ep_uuid}\n"
    path.write_text(text, encoding="utf-8")


def patch_registry(rows: list[dict[str, str]]) -> int:
    by = {r["uuid"]: r for r in rows}
    changes = 0

    for seq, slug in EPISODES:
        uuid = f"VT_episode_ep{seq:02d}"
        new_notes = build_episode_notes(seq, slug)
        if by[uuid]["notes"] != new_notes:
            by[uuid]["notes"] = new_notes
            changes += 1
        patch_episode_shadow(seq, slug)

    for cit_uuid, ep_uuid in CITATION_EP_LINKS.items():
        row = by[cit_uuid]
        ep_num = int(ep_uuid.replace("VT_episode_ep", ""))
        new_notes = clean_citation_notes(row["notes"], ep_num)
        if row["notes"] != new_notes:
            row["notes"] = new_notes
            changes += 1

        links = parse_links(row["topo_links"])
        if ep_uuid not in links:
            links.append(ep_uuid)
            row["topo_links"] = join_links(links)
            sync_shadow_topo(cit_uuid, row["topo_links"])
            changes += 1

        ep_row = by[ep_uuid]
        ep_links = parse_links(ep_row["topo_links"])
        if cit_uuid not in ep_links:
            ep_links.append(cit_uuid)
            ep_row["topo_links"] = join_links(ep_links)
            sync_shadow_topo(ep_uuid, ep_row["topo_links"])
            changes += 1

        patch_citation_shadow(cit_uuid, ep_uuid)

    return changes


def patch_craft_paths() -> int:
    changes = 0
    for path, old, new in TOOL_SOURCE_REPLACEMENTS:
        text = path.read_text(encoding="utf-8")
        if old in text:
            path.write_text(text.replace(old, new), encoding="utf-8")
            changes += 1
    for seq, slug in EPISODES:
        stem = episode_stem(seq, slug)
        pipe = ROOT / "2_craft/pipelines" / f"{stem}.md"
        if not pipe.is_file():
            continue
        text = pipe.read_text(encoding="utf-8")
        if "pyramids-series/pipeline.md" in text:
            pipe.write_text(text.replace("pyramids-series/pipeline.md", "2_craft/pipeline.md"), encoding="utf-8")
            changes += 1
    return changes


def main() -> int:
    with CSV_PATH.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames
        assert fieldnames
        rows = list(reader)

    craft = patch_craft_paths()
    reg = patch_registry(rows)

    with CSV_PATH.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print(f"repair next 3: {reg} registry/topo change(s), {craft} craft path(s)")

    result = subprocess.run([sys.executable, str(QA)], cwd=ROOT, capture_output=True, text=True)
    print(result.stdout.strip())
    if result.stderr:
        print(result.stderr.strip(), file=sys.stderr)
    return result.returncode


if __name__ == "__main__":
    sys.exit(main())
