# 缺口清單 · 散夹 → zip（repair next 0）

> **目的**：收束前核对 · **next 1** 迁入 · **next 4** 删根目录冗余  
> **蓝图表** `tZpBp701` §1：根目录 **只得** `{slug}.zip`

---

## 草稿区根目录（现况 · repair 4 ✅）

| 路径 | 角色 | repair 后 |
|------|------|-----------|
| `pyramids-series.zip` | **目标唯一本体** | ✅ 保留 |
| `pyramids-series-workspace/` | 施工解压夹 | ❌ 已删 |
| `pyramids-series/` | 旧系列 meta 散夹 | ❌ 已删 |
| `01-`…`04-pyramid-*` | 旧四期散夹 | ❌ 已删 |

---

## 逐文件缺口（zip 内尚无 · 散夹有）

### 四期 slug 对照

| Ep | 散夹 | slug |
|----|------|------|
| 1 | `01-pyramid-construction-archaeology/` | `pyramid-construction-archaeology` |
| 2 | `02-pyramid-china-chronology/` | `pyramid-china-chronology` |
| 3 | `03-pyramid-alien-claim-critique/` | `pyramid-alien-claim-critique` |
| 4 | `04-pyramid-reading-method/` | `pyramid-reading-method` |

### next 1 迁入路径（写死）

| 源（散夹） | 目标（zip 内） | 批 |
|------------|----------------|-----|
| `{0N}-*/article.en.md` | `1_articles/en/ep0N_{slug}.md` | 1 |
| `{0N}-*/work-paper.md` | `2_craft/work_papers/ep0N_{slug}.md` | 1 |
| `{0N}-*/pipeline.md` | `2_craft/pipelines/ep0N_{slug}.md` | 1 |
| `{0N}-*/sources.md` | `2_craft/sources/ep0N_{slug}.md` | 1 |
| `{0N}-*/20260610_*.txt`（P*） | 已在 `3_citations/archive_P/` | — 可跳过 |

### next 2 正文源（zh）✅

| 源 | 目标 | 批 |
|----|------|-----|
| `{0N}-*/article.md` | `1_articles/ep0N_{slug}.md` | 2 ✅ |
| （已有） | `1_articles/ep0N_{slug}.docx` | 2 ✅ `md_to_docx.py` |

### 已在 zip · 无需从散夹再迁

| 内容 | zip 位置 |
|------|----------|
| 系列 meta | `2_craft/series-plan.md` · `DELIVERY.md` · `pipeline.md` · `en-glossary.md` |
| 四工具摘要 | `2_craft/tool_*.md` |
| 12 B/A 引述厚 MD | `3_citations/*.md` |
| P* archive | `3_citations/archive_P/` |
| registry + 22 shadow | `pyramids_registry.csv` · `4_md/` |
| 四期 docx（zh） | `1_articles/ep0N_*.docx` |

### `pyramids-series/` vs `2_craft/`

| 散夹文件 | workspace 状态 |
|----------|----------------|
| `series-plan.md` | ✅ `2_craft/series-plan.md` |
| `DELIVERY.md` | ✅ |
| `pipeline.md` | ✅ |
| `en-glossary.md` | ✅ |

---

## registry 备注（next 3 改）✅

| 项 | 目标 | 状态 |
|----|------|------|
| episode `notes` | zip 内 `md源`／`en源`／craft 路径 | ✅ repair 3 |
| citation `ep link next 3` | topo ↔ episode 双向 | ✅ repair 3 |
| `2_craft/tool_*.md` 来源 | `work_papers/ep0N_*.md` | ✅ repair 3 |
| `2_craft/pipelines/` | `2_craft/pipeline.md` | ✅ repair 3 |

---

## 修改纪录

- 2026-07-13 · repair next 0 · 缺口表定案
- 2026-07-13 · repair next 1 · 16 档自散夹 copy 入 zip 内（en / work_papers / pipelines / sources）
- 2026-07-13 · repair next 2 · zh `1_articles/ep0N_*.md` + docx 重打；registry／shadow 改 md 源路径
- 2026-07-13 · repair next 3 · episode notes／shadow craft 路径；4 citation topo；`repair_next3.py` + QA PASS
- 2026-07-13 · repair next 4 · QA → `package_zip.py` → 删 workspace + 散夹；根只得 zip
- 2026-07-13 · repair next 5 · `unzip_work.py` · `package_zip.py --clean` · `6_py/README.md` Mode A SOP
- 2026-07-13 · repair next 6 · `ACCEPTANCE_consolidate.md` · 根只得 zip · QA PASS
