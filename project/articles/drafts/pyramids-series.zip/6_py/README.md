# 6_py · QA · Mode A 工作流

> **收束 repair next 5** ✅ · 藍圖 `tZpBp701` §15  
> **根目錄**：`草稿區/` 只得 `pyramids-series.zip` · 改文短暫解壓

---

## Mode A · 改 zip 三步

```bash
# 0. 草稿區（只得 zip）
cd 草稿區

# 1. 解壓
python3 pyramids-series/6_py/unzip_work.py   # 首次：先 unzip 一次取出腳本，見下「冷啟動」
# 或（已解壓時）
cd pyramids-series && python3 6_py/unzip_work.py

# 2. 改文（例：confirm ① 前改 zh 正文）
#    1_articles/ep0N_{slug}.md · en/ · 2_craft/ …

# 3. QA → 封包 → 刪解壓夾
python3 6_py/qa_registry.py
python3 6_py/package_zip.py --clean
```

**冷啟動**（根目錄只得 zip、未有 `pyramids-series/`）：

```bash
cd 草稿區
unzip -q pyramids-series.zip -d pyramids-series
cd pyramids-series
python3 6_py/unzip_work.py    # 確認結構；之後用上面三步
```

`--clean` 後根目錄恢復 **只得** `pyramids-series.zip`。

---

## 腳本

| 腳本 | 用途 |
|------|------|
| `unzip_work.py` | 解壓 `{slug}.zip` → `草稿區/pyramids-series/` |
| `qa_registry.py` | 全量驗收（exit 0 = PASS） |
| `package_zip.py` | QA 通過後打 zip；`--clean` 刪解壓夾 |
| `md_to_docx.py` | zh md → docx（源讀 zip 內 `1_articles/`） |
| `repair_next3.py` | registry／shadow 路徑對齊（收束用） |

### `qa_registry.py`

```bash
python3 6_py/qa_registry.py              # 全量驗收
python3 6_py/qa_registry.py --report     # 寫入 QA_REPORT.txt
python3 6_py/qa_registry.py --repair-topo
```

### `package_zip.py`

```bash
python3 6_py/package_zip.py              # QA → ../pyramids-series.zip
python3 6_py/package_zip.py --clean      # 封包後刪本解壓夾（Mode A）
```

### `unzip_work.py`

```bash
python3 6_py/unzip_work.py               # 解壓（已存在則提示）
python3 6_py/unzip_work.py --force       # 覆蓋解壓
```

---

## 檢查項（`qa_registry.py`）

| 類別 | 內容 |
|------|------|
| CSV | header 16 欄 · `VT_*` 唯一 |
| 格式 | `qutrit` 六段 · `vsm` 9 位 · layer/item_type |
| shadow | `m_path` = `4_md/{uuid}.md` · primary 唯一 |
| gravity | citation 必填 8 碼 · 其他必空 |
| episode | 4 期 · zip 內 `md源`／en／craft 路徑 · docx 存在 |
| 厚內容 | notes `厚文：` 路徑存在 |
| 引述 | `3_citations/*.md` 含 `## 原文摘錄` + blockquote |
| topo | zip 內雙向 |
| 憲章 | `WORKSPACE.md` · `2_csv/schema.md` |

---

## 施工腳本（歷史 · 非日常）

| 腳本 | 批 |
|------|-----|
| `_build_citations_next2.py` | zip 2 |
| `_build_episodes_next3.py` | zip 3 |
| `md_to_docx.py` | zip 4 / repair 2 |

---

## 修改紀錄

- 2026-07-13 · zip next 6–8 · qa + package
- 2026-07-13 · repair next 5 · `unzip_work.py` · Mode A SOP · `package_zip.py --clean`
