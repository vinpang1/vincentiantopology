#!/usr/bin/env python3
"""repair next 2 / zip next 4: 1_articles/ep0N_{slug}.md → *.docx (python-docx)."""
from __future__ import annotations

import csv
import re
import shutil
from pathlib import Path

from docx import Document
from docx.oxml.ns import qn
from docx.shared import Pt

ROOT = Path(__file__).resolve().parents[1]
DRAFTS = ROOT.parent
OUT = ROOT / "1_articles"
CSV_PATH = ROOT / "pyramids_registry.csv"
MD4 = ROOT / "4_md"

# (series_seq, slug)
EPISODES = [
    (1, "pyramid-construction-archaeology"),
    (2, "pyramid-china-chronology"),
    (3, "pyramid-alien-claim-critique"),
    (4, "pyramid-reading-method"),
]

FONT_LATIN = "Georgia"
FONT_CJK = "PingFang TC"


def episode_stem(seq: int, slug: str) -> str:
    return f"ep{seq:02d}_{slug}"


def scatter_article(seq: int, slug: str) -> Path:
    return DRAFTS / f"{seq:02d}-{slug}" / "article.md"


def strip_frontmatter(text: str) -> str:
    if text.startswith("---"):
        end = text.find("\n---", 3)
        if end != -1:
            return text[end + 4 :].lstrip("\n")
    return text


def set_run_font(run, *, bold: bool = False, italic: bool = False) -> None:
    run.bold = bold
    run.italic = italic
    run.font.name = FONT_LATIN
    run.font.size = Pt(11)
    r = run._element.get_or_add_rPr()
    r.rFonts.set(qn("w:eastAsia"), FONT_CJK)


def add_inline(paragraph, text: str) -> None:
    pattern = re.compile(r"(\*\*[^*]+\*\*|\*[^*]+\*|[^*]+)")
    for part in pattern.findall(text):
        if part.startswith("**") and part.endswith("**"):
            run = paragraph.add_run(part[2:-2])
            set_run_font(run, bold=True)
        elif part.startswith("*") and part.endswith("*"):
            run = paragraph.add_run(part[1:-1])
            set_run_font(run, italic=True)
        elif part:
            run = paragraph.add_run(part)
            set_run_font(run)


def add_heading(doc: Document, text: str, level: int) -> None:
    p = doc.add_heading(level=min(level, 3))
    p.clear()
    add_inline(p, text)


def parse_table_row(line: str) -> list[str]:
    line = line.strip()
    if line.startswith("|"):
        line = line[1:]
    if line.endswith("|"):
        line = line[:-1]
    return [c.strip() for c in line.split("|")]


def is_table_sep(line: str) -> bool:
    return bool(re.match(r"^\|?[\s\-:|]+\|?$", line.strip()))


def md_to_docx(md_path: Path, docx_path: Path) -> None:
    body = strip_frontmatter(md_path.read_text(encoding="utf-8"))
    lines = body.splitlines()
    doc = Document()
    normal = doc.styles["Normal"]
    normal.font.name = FONT_LATIN
    normal.font.size = Pt(11)
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), FONT_CJK)

    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        if not stripped:
            i += 1
            continue

        if stripped == "---":
            i += 1
            continue

        if stripped.startswith("# "):
            add_heading(doc, stripped[2:].strip(), 1)
            i += 1
            continue

        if stripped.startswith("## "):
            add_heading(doc, stripped[3:].strip(), 2)
            i += 1
            continue

        if stripped.startswith("### "):
            add_heading(doc, stripped[4:].strip(), 3)
            i += 1
            continue

        if stripped.startswith("|") and i + 1 < len(lines) and is_table_sep(lines[i + 1]):
            headers = parse_table_row(stripped)
            i += 2
            table = doc.add_table(rows=1, cols=len(headers))
            table.style = "Table Grid"
            for j, h in enumerate(headers):
                cell = table.rows[0].cells[j]
                cell.text = ""
                add_inline(cell.paragraphs[0], h)
            while i < len(lines) and lines[i].strip().startswith("|"):
                row_vals = parse_table_row(lines[i])
                row = table.add_row().cells
                for j, val in enumerate(row_vals):
                    if j < len(row):
                        row[j].text = ""
                        add_inline(row[j].paragraphs[0], val)
                i += 1
            doc.add_paragraph()
            continue

        if stripped.startswith("- "):
            p = doc.add_paragraph(style="List Bullet")
            p.clear()
            add_inline(p, stripped[2:])
            i += 1
            continue

        parts = [stripped]
        i += 1
        while i < len(lines):
            nxt = lines[i]
            if not nxt.strip():
                break
            if nxt.lstrip().startswith(("#", "-", "|", "---")):
                break
            if parts[-1].endswith("  "):
                parts[-1] = parts[-1][:-2] + nxt.strip()
            else:
                parts.append(nxt.strip())
            i += 1
        p = doc.add_paragraph()
        add_inline(p, " ".join(parts))

    doc.save(docx_path)


def sync_zh_md(seq: int, slug: str) -> Path:
    """Ensure zip-internal zh md exists (copy scatter only if still present)."""
    scatter = scatter_article(seq, slug)
    md_path = OUT / f"{episode_stem(seq, slug)}.md"
    if scatter.is_file():
        shutil.copy2(scatter, md_path)
    elif not md_path.is_file():
        raise SystemExit(f"Missing zh md: {md_path} (scatter gone: {scatter})")
    return md_path


def patch_episode_registry(seq: int, slug: str) -> None:
    stem = episode_stem(seq, slug)
    md_rel = f"1_articles/{stem}.md"
    rows: list[dict[str, str]] = []
    with CSV_PATH.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames
        assert fieldnames
        for row in reader:
            if row["uuid"] == f"VT_episode_ep{seq:02d}":
                notes = row["notes"]
                notes = re.sub(r";?md源=[^;]*", "", notes)
                notes = re.sub(r";?docx✓", "", notes)
                notes = re.sub(r";?docx next 4", "", notes)
                notes = f"{notes};md源={md_rel};docx✓".lstrip(";")
                row["notes"] = notes
            rows.append(row)
    with CSV_PATH.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def patch_shadow(ep_n: str, slug: str) -> None:
    stem = episode_stem(int(ep_n), slug)
    path = MD4 / f"VT_episode_ep{ep_n}.md"
    if not path.exists():
        return
    text = path.read_text(encoding="utf-8")
    text = re.sub(
        r"正文源：`[^`]+`",
        f"正文源：`1_articles/{stem}.md`",
        text,
    )
    if "repair next 2" not in text:
        text = text.replace(
            "- 2026-07-13 · zip next 4 · docx 交付",
            "- 2026-07-13 · zip next 4 · docx 交付\n- 2026-07-13 · repair next 2 · zh md 源入 1_articles/",
        )
    path.write_text(text, encoding="utf-8")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    for seq, slug in EPISODES:
        md_path = sync_zh_md(seq, slug)
        docx_path = OUT / f"{episode_stem(seq, slug)}.docx"
        md_to_docx(md_path, docx_path)
        patch_shadow(f"{seq:02d}", slug)
        patch_episode_registry(seq, slug)
        print(f"OK {md_path.name} → {docx_path.name}")

    print(f"Done: {len(EPISODES)} zh md + docx in {OUT}")


if __name__ == "__main__":
    main()
