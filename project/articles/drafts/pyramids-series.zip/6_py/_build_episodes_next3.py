#!/usr/bin/env python3
"""One-off: zip next 3 episode shadows + topo links to tools/citations."""
from __future__ import annotations

import csv
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MD4 = ROOT / "4_md"
CSV = ROOT / "pyramids_registry.csv"

EPISODES = [
    {
        "n": "01",
        "seq": 1,
        "slug": "pyramid-construction-archaeology",
        "title": "我不知道金字塔是誰建的，但我知道什麼不能當證據",
        "description": "外星人？人力？我先不選邊。這一期只畫一張圖：哪些能核對、哪些只能推、哪些該留白。",
        "tool": "VT_tool_evidence_grid",
        "tool_kw": "證據四格",
        "citations": ["nk8jIIvx", "sOr3Lhqe", "2MshQLAD", "phVXjCiA"],
        "qutrit": "2/1/2/1/2/2",
        "vsm": "102130210",
    },
    {
        "n": "02",
        "seq": 2,
        "slug": "pyramid-china-chronology",
        "title": "「同期」不等於「可比」——吉薩築塔時，中國在什麼階段？",
        "description": "金字塔系列 S2：吉薩築塔時把上古中國拉進同一時間窗口——雙軸並讀，看階段與路徑。",
        "tool": "VT_tool_china_egypt_axes",
        "tool_kw": "雙軸對讀",
        "citations": ["SL9cxP8Y", "kR3mNpW8", "vT2xQmL5", "sOr3Lhqe"],
        "qutrit": "2/1/2/1/2/2",
        "vsm": "102130210",
    },
    {
        "n": "03",
        "seq": 3,
        "slug": "pyramid-alien-claim-critique",
        "title": "外星說過不過關？——用三關檢驗「證據不足」的逃逸",
        "description": "金字塔系列 S3：用第一期的四格，檢驗外星建造假說——數學、工程量、遺址系統各過一關。",
        "tool": "VT_tool_alien_three_gates",
        "tool_kw": "外星三關",
        "citations": ["nk8jIIvx", "2MshQLAD", "phVXjCiA", "sOr3Lhqe"],
        "qutrit": "2/1/2/1/2/2",
        "vsm": "102130210",
    },
    {
        "n": "04",
        "seq": 4,
        "slug": "pyramid-reading-method",
        "title": "事實、推斷、敘事——讀史前史的方法總裝",
        "description": "金字塔系列 S4 收束：陰謀敘事三層精簡演練（非事實主張）＋四期工具總裝七項。",
        "tool": "VT_tool_method_seven",
        "tool_kw": "方法總裝",
        "citations": ["nk8jIIvx", "phVXjCiA", "kR7mNpQx", "sOr3Lhqe"],
        "qutrit": "2/1/2/1/2/2",
        "vsm": "102130210",
        "legal": True,
    },
]


def ep_id(n: str) -> str:
    return f"VT_episode_ep{n}"


def cit_id(sm: str) -> str:
    return f"VT_citation_{sm}"


def merge_topo(existing: str, *add: str) -> str:
    parts: list[str] = []
    seen: set[str] = set()
    for raw in (existing, *add):
        for p in raw.split("|"):
            p = p.strip()
            if p and p not in seen:
                seen.add(p)
                parts.append(p)
    return "|".join(parts)


def shadow_md(ep: dict) -> str:
    n = ep["n"]
    uid = ep_id(n)
    cites = "|".join(cit_id(c) for c in ep["citations"])
    topo = merge_topo(ep["tool"], cites)
    legal = "\n> **Agent 4 必審**（陰謀演練節 · 非事實主張）" if ep.get("legal") else ""
    p_path = f"1_articles/ep{n}_{ep['slug']}.docx"
    return f"""---
uuid: {uid}
subject_id: VT_sub_episode_ep{n}
item_type: episode
layer: 实
is_primary_shadow: true
p_path: {p_path}
m_path: 4_md/{uid}.md
view: ep{n}_whole
name: "{ep['title']}"
series_seq: {ep['seq']}
keywords: pyramids|ep{ep['seq']}|{ep['tool_kw']}
qutrit: "{ep['qutrit']}"
vsm: "{ep['vsm']}"
topo_links: {topo}
gravity_links: ""
---

# doc_summary

{ep['description']}

**slug** `{ep['slug']}` · **pipeline_stage** `awaiting_draft_confirm` · 正文源：`草稿區/0{ep['seq']}-{ep['slug']}/article.md` · docx next 4{legal}

## 修改紀錄

- 2026-07-13 · zip next 3 · episode shadow
"""


def patch_shadow_topo(path: Path, new_topo: str) -> None:
    if not path.exists():
        return
    text = path.read_text(encoding="utf-8")
    if "topo_links:" not in text:
        return
    text = re.sub(
        r"^topo_links:.*$",
        f"topo_links: {new_topo}",
        text,
        count=1,
        flags=re.MULTILINE,
    )
    path.write_text(text, encoding="utf-8")


def main() -> None:
    rows: list[dict[str, str]] = []
    with CSV.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames
        assert fieldnames
        for row in reader:
            rows.append(row)

    by_uuid = {r["uuid"]: r for r in rows}
    ep_uuids = [ep_id(ep["n"]) for ep in EPISODES]
    all_eps_topo = "|".join(ep_uuids)

    # episode shadows + rows
    for ep in EPISODES:
        n = ep["n"]
        uid = ep_id(n)
        (MD4 / f"{uid}.md").write_text(shadow_md(ep), encoding="utf-8")
        cites_topo = "|".join(cit_id(c) for c in ep["citations"])
        topo = merge_topo(ep["tool"], cites_topo)
        rows.append(
            {
                "uuid": uid,
                "layer": "实",
                "item_type": "episode",
                "subject_id": f"VT_sub_episode_ep{n}",
                "is_primary_shadow": "true",
                "p_path": f"1_articles/ep{n}_{ep['slug']}.docx",
                "m_path": f"4_md/{uid}.md",
                "view": f"ep{n}_whole",
                "name": ep["title"],
                "series_seq": str(ep["seq"]),
                "keywords": f"pyramids|ep{ep['seq']}|{ep['tool_kw']}",
                "qutrit": ep["qutrit"],
                "vsm": ep["vsm"],
                "topo_links": topo,
                "gravity_links": "",
                "notes": f"stage=awaiting_draft_confirm;slug={ep['slug']};md源=草稿區/0{ep['seq']}-{ep['slug']}/article.md;docx next 4",
            }
        )

    # series_plan ↔ episodes
    sp = by_uuid["VT_series_plan"]
    sp["topo_links"] = merge_topo(sp["topo_links"], all_eps_topo)
    patch_shadow_topo(MD4 / "VT_series_plan.md", sp["topo_links"])

    # tools ↔ episodes
    for ep in EPISODES:
        uid = ep_id(ep["n"])
        tool = by_uuid[ep["tool"]]
        tool["topo_links"] = merge_topo(tool["topo_links"], uid)
        tool["notes"] = tool["notes"].replace("ep link next 3", f"ep{ep['seq']} linked")
        patch_shadow_topo(MD4 / f"{ep['tool']}.md", tool["topo_links"])

    # citations ↔ episodes
    for ep in EPISODES:
        uid = ep_id(ep["n"])
        for sm in ep["citations"]:
            cid = cit_id(sm)
            if cid not in by_uuid:
                continue
            c = by_uuid[cid]
            c["topo_links"] = merge_topo(c["topo_links"], uid)
            c["notes"] = c["notes"].replace("ep link next 3", f"ep{ep['seq']} linked")
            patch_shadow_topo(MD4 / f"{cid}.md", c["topo_links"])

    with CSV.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print(f"Wrote {len(EPISODES)} episode shadows; registry rows={len(rows)}")


if __name__ == "__main__":
    main()
