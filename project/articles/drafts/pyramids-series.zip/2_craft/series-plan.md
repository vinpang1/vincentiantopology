# 金字塔系列 · 策劃摘要（v2）

> P-agent `p7SrPl4K` v0.4 · Batch 0–5 ✓ · `awaiting_draft_confirm`

| Ep | 資料夾 | v2 標題 | 本期工具 |
|----|--------|---------|----------|
| 1 | `01-pyramid-construction-archaeology` | 我不知道金字塔是誰建的，但我知道什麼不能當證據 | 證據四格 |
| 2 | `02-pyramid-china-chronology` | 「同期」不等於「可比」——吉薩築塔時，中國在什麼階段？ | 文獻軸／考古軸 |
| 3 | `03-pyramid-alien-claim-critique` | 外星說過不過關？——用三關檢驗「證據不足」的逃逸 | 外星三關 |
| 4 | `04-pyramid-reading-method` | 事實、推斷、敘事——讀史前史的方法總裝 | 總裝 7 項 |

**弧線**：四格查案 → 中埃對讀 → 外星三關 → 陰謀三層＋方法總裝

詳見 `DELIVERY.md` · 各 slug 之 `work-paper.md` · agent-db `p7SrPl4K`
