# 交付清單 · pyramids 系列（v2）

> Agent 1 · **v0.4** · `awaiting_draft_confirm` · 2026-06-28

## 路徑（slug 對調後）

| Ep | 資料夾 | `slug` |
|----|--------|--------|
| 1 | `01-pyramid-construction-archaeology/` | `pyramid-construction-archaeology` |
| 2 | `02-pyramid-china-chronology/` | `pyramid-china-chronology` |
| 3 | `03-pyramid-alien-claim-critique/` | `pyramid-alien-claim-critique` |
| 4 | `04-pyramid-reading-method/` | `pyramid-reading-method` |

`草稿區/` → symlink 至 `project/articles/drafts/`。

**排序**：資料夾 `01-`…`04-` 與 `episode` 1–4 對齊 · **export URL**：`slug` + `episode`。

## v2 工具一覽

| Ep | 帶走 |
|----|------|
| 1 | 證據四格 |
| 2 | 文獻軸／考古軸 · 同期≠同級 |
| 3 | 外星三關 |
| 4 | 事實／推斷／敘事三層 · 讀史前史總裝七項 |

## 下一步

1. **confirm ①**（四期齊審）  
2. `@agent-02-edit` 校對四期  
3. `@agent-04-legal` 審 Ep4（陰謀演練 · 非事實主張）
