# Pipeline · pyramids 系列

> 四期專題 · `series: pyramids` · 產品線 ②  
> 策劃：`series-plan.md` · P-agent `p7SrPl4K` **v0.4**  
> **v2 Batch 0–5 ✓** · `awaiting_draft_confirm`

## 系列進度（v2 · slug 對調後）

| Ep | 資料夾 | v2 標題 | pipeline_stage | 備註 |
|----|--------|---------|----------------|------|
| 1 | `01-pyramid-construction-archaeology` | 我不知道…什麼不能當證據 | `awaiting_draft_confirm` | 證據四格 |
| 2 | `02-pyramid-china-chronology` | 同期≠可比 | `awaiting_draft_confirm` | 雙軸對讀 |
| 3 | `03-pyramid-alien-claim-critique` | 外星三關 | `awaiting_draft_confirm` | |
| 4 | `04-pyramid-reading-method` | 方法總裝 | `awaiting_draft_confirm` | **Agent 4 必審** |

## Agent 1 v2 清單

- [x] Batch 0–5 全 ✓
- [ ] **confirm ①** → `@agent-02-edit`
- [ ] Ep4 → `@agent-04-legal`（陰謀演練節）

---

## Human-A · 確認 ①

- [ ] 四期 v2 `article.md` 已閱
- [ ] 已指令 **@agent-02-edit**

**簽署 / 日期：**
