# 作層工作紙 · Ep4 · S4（v2）

> `04-pyramid-reading-method` · episode 4 · cycle S4 · 策劃 `p7SrPl4K` v0.4 · **Batch 4 ✓**

## 定案標題

《事實、推斷、敘事——讀史前史的方法總裝》

## 陰謀三層（精簡演練）+ 總裝七項

---

## 修改紀錄

- 2026-06-28 · Agent 1 · v2 Batch 4
