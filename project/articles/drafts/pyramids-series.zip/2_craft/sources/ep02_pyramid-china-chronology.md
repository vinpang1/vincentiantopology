# Sources · 02-pyramid-china-chronology

> v2 Batch 2（2026-06-28）：Ep2 中埃前移 · 正文主引 Eberhard + Erlitou T2 + Rawlinson（一句）· Petrie 本篇不出表

## 書名鎖定表（起稿前必填 · 2026-06-27 綁定）

正文 EFN、《引證索引》書名 **只准抄本表 `canonical_title`**。

| uuid / book_id | 作者 | **canonical_title** | 章／錨 | 梯隊 | 入引證索引 |
|----------------|------|---------------------|--------|------|------------|
| `SL9cxP8Y` | Eberhard | *A history of China*, 3d ed. rev. and enl. | Ch.I PREHISTORY；Ch.II SHANG | T3 | Y |
| `kR3mNpW8` / `zenodo_erlitou_statistical_chronology_2025` | （學術論文） | *Statistical Chronology of Erlitou: Constraining the Xia Dynasty's Origins* | Bayesian 建模；概率年代區間 | T2 | Y |
| `sOr3Lhqe` | Rawlinson | *Ancient Egypt* | 三角洲單調平原；古王國金字塔為王陵 | T3 | Y |
| `nk8jIIvx` | Petrie | *Ten years' digging in Egypt, 1881–1891* | Ch.I 三角測量；鋸切與管狀鑽 | T3 | N |
| `2MshQLAD` | Burr | *Ancient and modern engineering and the Isthmian canal* | Ch.6 The Pyramids | T3 | N |
| `bbh1gjCw` | Giles | *China and the Chinese* | 中西比較（希臘） | T3 | N |
| `W7F7GRGQ` | Eberhard | *A History of China*（Gutenberg 11367 · 初版） | Ch.I PREHISTORY（對照用） | T3 | N |
| `vT2xQmL5` | Qiu et al. | *Chronology of early China: A radiocarbon databank for Chinese archaeology* | 資料庫 v2023.4 | T2 | Y |
| `SbcAo2im` | 自產舊稿 | — | 改寫源 | — | N |
| `ky7XuH3B` | Baikie | *Peeps at Many Lands: Ancient Egypt* | 可選 | T3 | N |

## fetch_download

| book_id | 路徑 | 用途 |
|---------|------|------|
| `zenodo_erlitou_statistical_chronology_2025` | `~/Documents/Dev/fetch_download/下載/zenodo_erlitou_statistical_chronology_2025.bin` | 同 `kR3mNpW8` |
| `zenodo_china_radiocarbon_databank_2025` | `~/Documents/Dev/fetch_download/下載/zenodo_china_radiocarbon_databank_2025.bin` | 同 `vT2xQmL5`（Spin Map 已有全文 · fetch 未登記） |
| `copyright_*`（6 條） | `books.csv` · `external_candidates_pyramid_china_ep4.json` | 付費論文 · 僅書目 |

索引：`~/Documents/Dev/fetch_download/pyramid_china_ep4_bibliography.md`

## 出街引證索引對照

見 `article.md` §引證索引（4 條 · 無 uuid）· 書名以本表 `Y` 列為準。
