# Sources · 03-pyramid-alien-claim-critique

> v2 Batch 3（2026-06-28）：Ep3 外星三關 · 系列內 Petrie／Burr／希羅多德／Rawlinson 長引收束篇

## 書名鎖定表（起稿前必填 · 2026-06-27 綁定）

正文 EFN、《引證索引》書名 **只准抄本表 `canonical_title`**。

| uuid / book_id | 作者 | **canonical_title** | 章／錨 | 梯隊 | 入引證索引 |
|----------------|------|---------------------|--------|------|------------|
| `nk8jIIvx` | Petrie | *Ten years' digging in Egypt, 1881–1891* | Ch.I 吉薩；2π 爭議、精度參差、營房與可行性 | T3 | Y |
| `2MshQLAD` | Burr | *Ancient and modern engineering and the Isthmian canal* | Ch.6 The Pyramids；體量估算與動員 | T3 | Y |
| `sOr3Lhqe` | Rawlinson | *Ancient Egypt* | 陵墓傳統；駁「天文台說」 | T3 | Y |
| `phVXjCiA` | 希羅多德 | *An Account of Egypt*（Histories, Book II） | 十萬人、二十年工期記述 | T3 | Y |
| `HOEs1amN` | 自產舊稿 | — | 改寫源 | — | N |

## Spin Map（內部 · 只讀 B/A）

| uuid | 作者／來源 | 梯隊 | 引證表條目 |
|------|-----------|------|------------|
| `HOEs1amN` | 舊稿正本 | — | — |
| `nk8jIIvx` | Petrie | T3 | 2π／精度／營房 |
| `2MshQLAD` | Burr | T3 | 體量與動員 |
| `sOr3Lhqe` | Rawlinson | T3 | 系統陵墓邏輯 |
| `phVXjCiA` | 希羅多德 | T3 | 工期人力 |

## 出街引證索引對照

見 `article.md` §引證索引（4 條 · 無 uuid）· 書名以本表 `Y` 列為準。
