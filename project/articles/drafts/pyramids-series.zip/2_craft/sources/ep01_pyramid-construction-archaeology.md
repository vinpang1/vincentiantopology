# Sources · 01-pyramid-construction-archaeology

> v2 Batch 0（2026-06-28）：引證窄選不變 · Batch 1 起稿依 `work-paper.md` 四格示範入格

## 書名鎖定表（起稿前必填 · 2026-06-27 綁定）

正文 EFN、《引證索引》書名 **只准抄本表 `canonical_title`**。

| uuid / book_id | 作者 | **canonical_title** | 章／錨 | 梯隊 | 入引證索引 |
|----------------|------|---------------------|--------|------|------------|
| `nk8jIIvx` | Petrie | *Ten years' digging in Egypt, 1881–1891* | Ch.I 吉薩；測量、工具痕跡、工匠營房 | T3 | Y |
| `sOr3Lhqe` | Rawlinson | *Ancient Egypt* | 孟菲斯墓區；墓室、石棺與陵墓用途 | T3 | Y |
| `2MshQLAD` | Burr | *Ancient and modern engineering and the Isthmian canal* | Ch.6 The Pyramids；材料、花崗岩運輸 | T3 | Y |
| `phVXjCiA` | 希羅多德 | *An Account of Egypt*（Histories, Book II） | 胡夫工程人力、輪班與工期記述 | T3 | Y |
| `gO5inxjd` | Maspero | *History of Egypt, Chaldæa, Syria, Babylonia, and Assyria*（Vol. 2） | 徭役與稅收行政（可選） | T3 | N |
| `Zs6DCH68` | 自產舊稿 | — | 改寫源 | — | N |

## Spin Map（內部 · 只讀 B/A）

| uuid | 作者／來源 | 梯隊 | 引證表條目 |
|------|-----------|------|------------|
| `Zs6DCH68` | 舊稿正本 | — | — |
| `nk8jIIvx` | Petrie | T3 | 定題／測量與工具 |
| `sOr3Lhqe` | Rawlinson | T3 | 陵墓脈絡 |
| `2MshQLAD` | Burr | T3 | 材料與體量 |
| `phVXjCiA` | 希羅多德 | T3 | 人力工期 |
| `gO5inxjd` | Maspero | T3 | 可選（徭役背景） |

## 出街引證索引對照

見 `article.md` §引證索引（4 條 · 無 uuid）· 書名以本表 `Y` 列為準。

**禁止** copy Spin Map `P*`。
