# Sources · 04-pyramid-reading-method

> v2 Batch 4（2026-06-28）：Ep4 方法總裝 · slug 定案 `pyramid-reading-method`（Batch 5 資料夾更名）· **Agent 4 必審**（陰謀演練節）

## 書名鎖定表（起稿前必填 · 2026-06-28 更新）

正文 EFN、《引證索引》書名 **只准抄本表 `canonical_title`**。

| uuid / book_id | 作者 | **canonical_title** | 章／錨 | 梯隊 | 入引證索引 |
|----------------|------|---------------------|--------|------|------------|
| `nk8jIIvx` | Petrie | *Ten years' digging in Egypt, 1881–1891* | Ch.I 石棺須結構完成前置入 | T3 | Y |
| `phVXjCiA` | 希羅多德 | *An Account of Egypt*（Histories, Book II） | 工期與人力數量級記述 | T3 | Y |
| `kR7mNpQx` | Frazer | *The Golden Bough: A Study in Magic and Religion*（Vol. 06 of 12） | 王權、奧西里斯信仰與儀式記憶 | T3 | Y |
| `sOr3Lhqe` | Rawlinson | *Ancient Egypt* | 陵墓脈絡（對照陰謀版） | T3 | Y |
| `2MshQLAD` | Burr | *Ancient and modern engineering and the Isthmian canal* | Ch.6（對照用） | T3 | N |
| `FPIYc3RZ` | 自產舊稿 | — | 改寫源 | — | N |

## 合規備註

- 陰謀三層段落：**敘事演練 · 非事實主張**
- **Agent 4 必審**（`pipeline_stage: legal` · v2 全系列完成後）

## 出街引證索引對照

見 `article.md` §引證索引（4 條 · 無 uuid）· 書名以本表 `Y` 列為準。
