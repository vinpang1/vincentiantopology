# Pipeline · 02-pyramid-china-chronology

> 系列 `pyramids` · **episode 2** · S2 · 策劃 `p7SrPl4K` **v0.4**

## v2 重寫進度

| 批次 | 內容 | 狀態 |
|------|------|------|
| **2** | `article.md` v2（中埃前移） | ✓ 2026-06-28 |
| **5** | slug 對調 · `awaiting_draft_confirm` | ✓ 2026-06-28 |

- `pipeline_stage`: **`awaiting_draft_confirm`**

---

## Human-A · 確認 ①

見 `2_craft/pipeline.md`
