# Pipeline · 01-pyramid-construction-archaeology

> 系列 `pyramids` · **episode 1** · S1 · 策劃 `p7SrPl4K` **v0.4**

## v2 重寫進度

| 批次 | 內容 | 狀態 |
|------|------|------|
| **0–1** | 策劃 · Ep1 全文 | ✓ 2026-06-28 |
| **5** | slug 對調 · 系列互參 · `awaiting_draft_confirm` | ✓ 2026-06-28 |

- `pipeline_stage`: **`awaiting_draft_confirm`**

---

## Human-A · 確認 ①

見 `2_craft/pipeline.md`（四期齊審）
