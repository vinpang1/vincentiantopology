# Pyramids Series · EN Translation Bible · Batch 0

> **Series** `pyramids` · **Plan** `p7SrPl4K` v0.4  
> **Source** zh-Hant articles (Agent 2 revised · 2026-06-28)  
> **Status** G0 assumed · Batch 1 ✓  
> **Pipeline** EN Batch 1 (Ep1 translate) ✓ → Batch 2 (Ep1 edit) next

---

## 0. Scope

This file **locks** English wording for all four episodes.  
Batches 1–10 **must not** invent synonyms for locked terms.

| Layer | Rule |
|-------|------|
| **Translate (Agent 1)** | Faithful to zh meaning · use this glossary |
| **Edit (Agent 2)** | `voice.md` §Topics · `en/deep-topics.md` · Spin Map shadows `R61Wp9W7` + `TxpluTH3` before each edit batch |
| **Legal (Agent 4)** | Ep4 conspiracy drill · non-factual disclaimer intact |

---

## 1. Brand & byline

| zh-Hant | English |
|---------|---------|
| 萬脈同構｜文森思維 | **All Things Are One \| Vincentian Topology** |
| 作者：文森 | **Vincent** |

---

## 2. Series metadata

| Field | zh-Hant | English (locked) |
|-------|---------|------------------|
| `series` | `pyramids` | `pyramids` (unchanged) |
| `seriesTitle` | 金字塔：讀敘事，不賣結論 | **Pyramids: Read the Narrative, Don't Buy the Conclusion** |
| `section` | `topics` | `topics` |
| `lang` | `zh-Hant` | **`en`** |
| Target length | — | **~1,100–1,400 words/ep** (`en/deep-topics.md`) |

### Series observation (mother sentence)

**zh：** 當金字塔被當成「文明上限」的量尺，被量的往往不是石頭，而是哪一套時間表、哪一種敘事資格。

**en (locked):** When pyramids become the yardstick for a “civilizational ceiling,” what gets measured is rarely the stone—it is which timeline, and which narrative license, you accept.

### Reading contract (series-wide)

**zh：** 猜想可以，但要拿證據來對照材料。  
**en (locked):** Guesses are allowed—but check them against the evidence.

**zh：** 我不知道（誰建的）。  
**en (locked):** **I don't know** (who built them).

---

## 3. Episodes · titles & descriptions

| Ep | Folder | `slug` | Title (en · locked) |
|----|--------|--------|---------------------|
| 1 | `01-pyramid-construction-archaeology/` | `pyramid-construction-archaeology` | **I Don't Know Who Built the Pyramids—But I Know What Doesn't Count as Evidence** |
| 2 | `02-pyramid-china-chronology/` | `pyramid-china-chronology` | **Same Era, Not the Same Stage—What Was China Doing While Giza Rose?** |
| 3 | `03-pyramid-alien-claim-critique/` | `pyramid-alien-claim-critique` | **Do Alien Claims Hold Up? Three Tests for Evidence-Free Escape Routes** |
| 4 | `04-pyramid-reading-method/` | `pyramid-reading-method` | **Fact, Inference, Narrative—A Toolkit for Reading Deep Antiquity** |

### `description` (en · draft — edit pass may tighten)

| Ep | description |
|----|-------------|
| 1 | Aliens? Human labor? I won't pick a side yet. This episode maps what can be verified, what can only be inferred, and what should stay blank. |
| 2 | Pyramids S2: Giza's building peak in the same time window as early China—dual-axis reading of stage and path, not a contest. |
| 3 | Pyramids S3: Use Ep1's four-cell framework to test alien-build claims—math, logistics, and site-wide patterns. |
| 4 | Pyramids S4: A short conspiracy-narrative drill (not a factual claim) plus a seven-item toolkit for reading prehistory. |

---

## 4. Section headings (en)

| zh | en (locked) |
|----|-------------|
| 引言 | **Introduction** |
| 一目了然 | **At a Glance** |
| 總結 | **Summary** |
| 值得再思考 | **Worth Another Look** |
| 引證索引 | **Sources** |

Ep4 drill subheads (locked pattern):

| zh | en |
|----|-----|
| 陰謀版怎麼說（事實層） | **What the conspiracy version says (fact layer)** |
| 陰謀版怎麼說（推斷層） | **What the conspiracy version says (inference layer)** |
| 陰謀版怎麼說（敘事層） | **What the conspiracy version says (narrative layer)** |
| 文獻怎麼回 | **What the sources say back** |
| 讀者該分辨什麼 | **What readers should separate** |

---

## 5. Core terminology (locked)

### 5.1 Evidence four-cell framework · 證據四格

| zh (正文全稱) | en (locked) | Notes |
|---------------|-------------|-------|
| 證據四格 | **evidence four-cell framework** | First use: optional “four cells” |
| 四格 | **four cells** | After framework introduced |
| ① 可核對 | **① Verifiable** | Table may keep circled numbers |
| ② 合理推斷 | **② Reasonable inference** | |
| ③ 仍有爭議 | **③ Still disputed** | Table header zh used「爭議中」→ en **Still disputed** |
| ④ 誠實留白 | **④ Honest blank** | Not “empty” alone (ambiguity with ep2) |
| 可核對那一格 | **the verifiable cell** | |
| 跳格 | **skip a cell** | First use: gloss “(treating inference as verified fact)” |
| 對照材料 | **check against the evidence** | Replaces zh 對線 |

**Practical question (locked):** Can this line be **verified**—or only inferred, still disputed, or honestly left blank?

### 5.2 Ep2 · dual-axis reading · 雙軸對讀

| zh | en (locked) |
|----|-------------|
| 雙軸對讀 | **dual-axis reading** |
| 文獻軸 | **textual axis** |
| 考古軸 | **archaeological axis** |
| 並置對讀 | **side-by-side reading** |
| 時間重疊 | **temporal overlap** |
| 同一發展階段 | **same developmental stage** |
| 史書記憶方案 | **textual memory scheme** |
| 視覺不對稱 | **visual asymmetry** |
| 奇觀太搶眼，另一條線太安靜 | **the spectacle is loud; the other line is quiet** |

**Ep2 bridge (locked idea):** Many English readers will ask: *In the same era, what was happening elsewhere?* — use this as the entry, not a defensive “we're not ranking civilizations.”

### 5.3 Ep3 · three gates · 外星三關

| zh | en (locked) |
|----|-------------|
| 外星三關 | **three gates** (first: **three gates for alien claims**) |
| 逃逸敘事 | **escape narrative** |
| 證據不足的逃逸 | **evidence-free escape** / **escape when evidence runs out** |
| 第一／二／三關未過 | **Gate one/two/three: not passed** | |
| 競爭假說 | **competing hypothesis** |
| 偶發贈送 | **one-off gift** (alien “gift” framing) |

### 5.4 Ep4 · layers & toolkit

| zh | en (locked) |
|----|-------------|
| 事實、推斷、敘事 | **fact, inference, narrative** |
| 陰謀敘事 | **conspiracy narrative** |
| 陰謀論 | **conspiracy theory** | **Only** when quoting labels others use (Ep4) |
| 敘事演練 · 非事實主張 | **narrative drill · not a factual claim** |
| 讀史前／上古史總裝 | **toolkit for reading deep antiquity** |
| 後代往回套 | **retrojected chronology** / **reading later dates back onto early periods** | Body: plain English; avoid bare “retrojection” without gloss |
| 把討論關掉 | **shut the conversation down** | Replaces zh 關燈 |

### 5.5 Shared craft terms

| zh | en (locked) |
|----|-------------|
| 數量級記述 | **order-of-magnitude account** |
| 考勤表 | **attendance roll** / **payroll headcount** (metaphor for Herodotus) |
| 最低共識 | **minimum shared ground** |
| 訂單式敘事 / 完整故事 | **complete story** / **story that feels too complete** |
| 多中心世界 | **multipolar world** (of civilizations) |
| 文明卡尺 | **civilization yardstick** |

---

## 6. Episode tools (arc)

| Ep | zh tool | en (locked) |
|----|---------|--------------|
| 1 | 證據四格 | evidence four-cell framework |
| 2 | 雙軸對讀 | dual-axis reading |
| 3 | 外星三關 | three gates |
| 4 | 七項總裝 | seven-item toolkit |

**Arc (en):** four cells → China–Egypt side-by-side → three gates → conspiracy layers + toolkit

---

## 7. File & frontmatter rules

| Item | Rule |
|------|------|
| **EN draft file** | `{slug-folder}/article.en.md` |
| **zh unchanged** | `{slug-folder}/article.md` · `lang: zh-Hant` |
| **Sync** | `project/articles/drafts/` ↔ `草稿區/` |
| **Citation index** | `Author \| Work \| Passage` (English) |
| **EFN** | English name · role · dates · *Title* — per `citations.md` §英文 |
| **修改紀錄** | Append each batch; tag `EN Batch N` |
| **pipeline_stage (EN)** | `en_awaiting_translate` → `en_draft` → `en_edit` → `legal` |
| **export** | Same `series` + `episode`; `lang: en` distinguishes locale (confirm URL strategy at G2) |

### EN frontmatter template

```yaml
---
title: "…"
description: "…"
slug: pyramid-construction-archaeology   # same as zh
section: topics
series: pyramids
seriesTitle: "Pyramids: Read the Narrative, Don't Buy the Conclusion"
episode: 1
pipeline_stage: en_awaiting_translate
agent_last: search
lang: en
created: 2026-06-28
revised: 2026-06-28
edit_rules_version: "0.1"
compliance_rules_version: "0.1"
source_lang: zh-Hant
source_revision: "2026-06-28-agent02"
plan_version: "p7SrPl4K-v0.4"
en_glossary: "batch0-20260628"
draft: true
---
```

---

## 8. EN voice anchors (Agent 2 edit batches)

**Tier 1 shadows** (read before Batches 2, 4, 6, 8, 9):

| uuid | Work | Apply |
|------|------|-------|
| `R61Wp9W7` | *On the Art of Writing* (Quiller-Couch) | Short, direct sentences; avoid jargon loops; no template negation every section |
| `TxpluTH3` | *Elements of Style* | Omit needless words; concrete nouns; one idea per sentence where possible |

**Voice target:** simple–moderate **business essay / opinion column** — not academic abstract, not literary ornament.

**Anti-patterns (en):**

- Do not stack “I will not treat X as Y, but ask…” in every section (mirror zh D-type cap ≤2 per piece).
- Do not upgrade vocabulary to sound “smart.”
- **Matter, not form:** plain words for deep ideas.

---

## 9. Translation batch tracker

| Batch | Task | Status |
|-------|------|--------|
| **0** | EN glossary (this file) | ✓ |
| **1** | Ep1 translate | ✓ · `01-…/article.en.md` |
| **2** | Ep1 edit + shadows | ✓ · `en_edit` |
| 3 | Ep2 translate | ✓ · `02-…/article.en.md` |
| 4 | Ep2 edit + shadows | ✓ · `en_edit` |
| 5 | Ep3 translate | ✓ · `03-…/article.en.md` |
| 6 | Ep3 edit + shadows | ✓ · `en_edit` |
| 7 | Ep4 translate | ✓ · `04-…/article.en.md` |
| 8 | Ep4 edit + shadows | ✓ · `en_edit` |
| 9 | Series EN QA | ✓ · all `en_awaiting_legal` |
| 10 | `@agent-04-legal` | ✓ · all `en_awaiting_db_confirm` |

---

## 10. 👤 G0 · Your approval checklist

Before **Batch 1 (next)**:

- [ ] `seriesTitle` English OK?
- [ ] Four episode titles OK?
- [ ] Core terms (four-cell, skip a cell, escape narrative, dual-axis) OK?
- [ ] Ep2 title framing (invitation, not ranking) OK?
- [ ] File name `article.en.md` OK?

Reply **G0 pass** or note changes → then **`next 1`** for Ep1 translate.

---

## 修改紀錄

- 2026-06-28 · EN Batch 0 · glossary + pipeline bible · `awaiting_glossary_confirm`
- 2026-06-28 · EN Batch 1 · Ep1 translate complete
- 2026-06-28 · EN Batch 2 · Ep1 edit complete · `en_edit`
- 2026-06-28 · EN Batch 3 · Ep2 translate complete
- 2026-06-28 · EN Batch 4 · Ep2 edit complete · `en_edit`
- 2026-06-28 · EN Batch 5 · Ep3 translate complete
- 2026-06-28 · EN Batch 6 · Ep3 edit complete · `en_edit`
- 2026-06-28 · EN Batch 7 · Ep4 translate complete
- 2026-06-28 · EN Batch 8 · Ep4 edit complete · `en_edit` · drill disclaimers verified
- 2026-06-28 · EN Batch 9 · Series QA complete · terminology aligned · `en_awaiting_legal` all eps
- 2026-06-28 · EN Batch 10 · Agent 4 legal pass · all eps `en_awaiting_db_confirm`
