# 工具 · 文獻軸／考古軸（Ep2）

> 系列 `pyramids` · episode 2 · 同期 ≠ 同級

## 雙軸

| 軸 | 代表 | 語言 |
|----|------|------|
| **文獻軸** | Eberhard《A history of China》 | 史書系年、傳世文獻 |
| **考古軸** | Erlitou T2 等 | 遺址年代、概率區間 |

## 實用兩問

1. 我讀的是文獻層還是考古層？  
2. 「同期」是時間重疊，還是能力可比？

## 來源

`2_craft/work_papers/ep02_pyramid-china-chronology.md` · v2 Batch 2
