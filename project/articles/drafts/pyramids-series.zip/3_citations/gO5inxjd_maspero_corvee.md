# Maspero · History of Egypt (Vol.2)

> Spin Map B/A · `gravity_links: gO5inxjd` · **只讀** · 梯隊 T3  
> 系列 `pyramids` · 用於 ep1

## 書目

| 欄 | 內容 |
|----|------|
| 作者 | Gaston Maspero |
| 書名 | *History of Egypt, Chaldæa, Syria, Babylonia, and Assyria (Vol. 2)* |
| Spin Map `p_path` | `Physical_Reality/B03_History_Culture/20260603_history_of_egypt_chald_a_syria_babylonia_a_gO5inxjd.txt` |
| 章／錨 | Rural corvée · labour background (optional ep1) |

## 系列用途

用於：ep1 · 見各 slug `sources.md` 書名鎖定表

## 原文摘錄

> What the collection of the taxes had begun was almost always brought to a climax by the _corvées_. However numerous the royal and seignorial slaves might have been, they were insufficient for the cultivation of all the lands of the domains, and a part of Egypt must always have lain fallow, had not the number of workers been augmented by the addition of those who were in the position of freemen.

*來源：Spin Map Physical_Reality 正本（只讀抽取）· zip next 2*

## 修改紀錄

- 2026-07-13 · zip next 2 · 厚引述入 `3_citations/`
