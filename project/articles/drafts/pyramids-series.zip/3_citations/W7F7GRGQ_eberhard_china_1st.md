# Eberhard · A History of China (Gutenberg 11367)

> Spin Map B/A · `gravity_links: W7F7GRGQ` · **只讀** · 梯隊 T3  
> 系列 `pyramids` · 用於 ep2

## 書目

| 欄 | 內容 |
|----|------|
| 作者 | Wolfram Eberhard |
| 書名 | *A History of China (1st ed. · Gutenberg #11367)* |
| Spin Map `p_path` | `Physical_Reality/B03_History_Culture/20260627_a_history_of_china_eberhard_W7F7GRGQ.txt` |
| 章／錨 | Ch.I PREHISTORY（對照 3d ed.） |

## 系列用途

用於：ep2 · 見各 slug `sources.md` 書名鎖定表

## 原文摘錄

> About 1600 B.C. we come at last into the realm of history. Of the Shang dynasty, which now followed, we have knowledge both from later texts and from excavations and the documents they have brought to light.

*來源：Spin Map Physical_Reality 正本（只讀抽取）· zip next 2*

## 修改紀錄

- 2026-07-13 · zip next 2 · 厚引述入 `3_citations/`
