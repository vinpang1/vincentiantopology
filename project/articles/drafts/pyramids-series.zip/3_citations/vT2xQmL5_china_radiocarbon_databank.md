# Qiu et al. · China radiocarbon databank (T2)

> Spin Map B/A · `gravity_links: vT2xQmL5` · **只讀** · 梯隊 T2  
> 系列 `pyramids` · 用於 ep2

## 書目

| 欄 | 內容 |
|----|------|
| 作者 | Menghan Qiu; Linyao Du; Richard Staff; et al. |
| 書名 | *Chronology of early China: A radiocarbon databank for Chinese archaeology* |
| Spin Map `p_path` | `Physical_Reality/B03_History_Culture/20260627_china_radiocarbon_databank_202_vT2xQmL5.bin` |
| 章／錨 | v2023.4 databank column schema（xlsx 正本） |

## 系列用途

用於：ep2 · 見各 slug `sources.md` 書名鎖定表

## 原文摘錄

> Archaeological Information
> Radiocarbon Information
> Site Name · Byname · Chinese Name · Category · Era · Comment
> Region · Province · Prefecture · County
> Longitude (°E) · Latitude (°N) · Elevation (m)
> Dating Material · Technique · Uncertainty (yr) · Median (cal BP) · σ (yr)

*來源：Spin Map Physical_Reality 正本（只讀抽取）· zip next 2*

## 修改紀錄

- 2026-07-13 · zip next 2 · 厚引述入 `3_citations/`
