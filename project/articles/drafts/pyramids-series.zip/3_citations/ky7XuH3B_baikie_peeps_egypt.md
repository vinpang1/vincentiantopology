# Baikie · Peeps at Many Lands: Ancient Egypt

> Spin Map B/A · `gravity_links: ky7XuH3B` · **只讀** · 梯隊 T3  
> 系列 `pyramids` · 用於 ep2

## 書目

| 欄 | 內容 |
|----|------|
| 作者 | James Baikie |
| 書名 | *Peeps at Many Lands: Ancient Egypt* |
| Spin Map `p_path` | `Physical_Reality/B03_History_Culture/20260603_peeps_at_many_lands_ancient_egypt_ky7XuH3B.txt` |
| 章／錨 | Popular chronology tone（可選） |

## 系列用途

用於：ep2 · 見各 slug `sources.md` 書名鎖定表

## 原文摘錄

> The Pyramids, for instance, those huge piles that are still the wonder of the world, were far older than any building now standing in Europe, before Joseph was sold to be a slave in Potiphar's house. Hundreds upon hundreds of years before anyone had ever heard of the Greeks and the Romans, there were great Kings reigning in Egypt

*來源：Spin Map Physical_Reality 正本（只讀抽取）· zip next 2*

## 修改紀錄

- 2026-07-13 · zip next 2 · 厚引述入 `3_citations/`
