# Rawlinson · Ancient Egypt

> Spin Map B/A · `gravity_links: sOr3Lhqe` · **只讀** · 梯隊 T3  
> 系列 `pyramids` · 用於 ep1 · ep2 · ep3 · ep4

## 書目

| 欄 | 內容 |
|----|------|
| 作者 | George Rawlinson |
| 書名 | *Ancient Egypt* |
| Spin Map `p_path` | `Physical_Reality/B03_History_Culture/20260610_ancient_egypt_sOr3Lhqe.txt` |
| 章／錨 | Pyramid builders · royal tombs at Gizeh |

## 系列用途

用於：ep1 · ep2 · ep3 · ep4 · 見各 slug `sources.md` 書名鎖定表

## 原文摘錄

> The fashion of burying in pyramids continued to the close of Manetho's sixth dynasty, but no later monarchs rivalled the great works of Khufu and Shafra. The tombs of their successors were monuments of a moderate size, involving no oppression of the people, but perhaps rather improving their condition by causing a rise in the rate of wages.

*來源：Spin Map Physical_Reality 正本（只讀抽取）· zip next 2*

## 修改紀錄

- 2026-07-13 · zip next 2 · 厚引述入 `3_citations/`
