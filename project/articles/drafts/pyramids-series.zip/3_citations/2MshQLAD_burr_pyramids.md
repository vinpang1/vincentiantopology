# Burr · Pyramids (Ch.6)

> Spin Map B/A · `gravity_links: 2MshQLAD` · **只讀** · 梯隊 T3  
> 系列 `pyramids` · 用於 ep1 · ep3

## 書目

| 欄 | 內容 |
|----|------|
| 作者 | Burr |
| 書名 | *Ancient and modern engineering and the Isthmian canal* |
| Spin Map `p_path` | `Physical_Reality/B11_Engineering_Design/20260604_ancient_and_modern_engineering_and_the_ist_2MshQLAD.txt` |
| 章／錨 | Ch.6 The Pyramids · volume · granite haul |

## 系列用途

用於：ep1 · ep3 · 見各 slug `sources.md` 書名鎖定表

## 原文摘錄

> The Great Pyramid has a square base, which was originally 764 feet on a side, with a height of apex above the surface of the ground of over 480 feet. This great mass of masonry contains about 3,500,000 cubic yards and weighs nearly 7,000,000 tons.
> 
> The Greek historian Herodotus states that its construction required the labor of 100,000 men for twenty years. An enormous quantity of granite was required to be transported about 500 miles down the Nile from the quarries at Syene.

*來源：Spin Map Physical_Reality 正本（只讀抽取）· zip next 2*

## 修改紀錄

- 2026-07-13 · zip next 2 · 厚引述入 `3_citations/`
