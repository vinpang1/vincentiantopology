# Eberhard · A history of China (3d ed.)

> Spin Map B/A · `gravity_links: SL9cxP8Y` · **只讀** · 梯隊 T3  
> 系列 `pyramids` · 用於 ep2

## 書目

| 欄 | 內容 |
|----|------|
| 作者 | Wolfram Eberhard |
| 書名 | *A history of China, 3d ed. rev. and enl.* |
| Spin Map `p_path` | `Physical_Reality/B03_History_Culture/20260603_a_history_of_china_3d_ed_rev_and_enl_SL9cxP8Y.txt` |
| 章／錨 | Ch.I PREHISTORY · Ch.II SHANG |

## 系列用途

用於：ep2 · 見各 slug `sources.md` 書名鎖定表

## 原文摘錄

> About 1600 B.C. we come at last into the realm of history. Of the Shang dynasty, which now followed, we have knowledge both from later texts and from excavations and the documents they have brought to light. The Shang civilization, an evident off-shoot of the Lung-shan culture (Tai, Yao, and Tunguses), but also with elements of the Hsia culture (with Tibetan and Mongol and/or Turkish elements), was beyond doubt a high civilization.

*來源：Spin Map Physical_Reality 正本（只讀抽取）· zip next 2*

## 修改紀錄

- 2026-07-13 · zip next 2 · 厚引述入 `3_citations/`
