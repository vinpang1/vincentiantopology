# Petrie · Ten years' digging

> Spin Map B/A · `gravity_links: nk8jIIvx` · **只讀** · 梯隊 T3  
> 系列 `pyramids` · 用於 ep1 · ep3 · ep4

## 書目

| 欄 | 內容 |
|----|------|
| 作者 | Flinders Petrie |
| 書名 | *Ten years' digging in Egypt, 1881–1891* |
| Spin Map `p_path` | `Physical_Reality/B03_History_Culture/20260610_ten_years_digging_in_egypt_1881_1891_nk8jIIvx.txt` |
| 章／錨 | Ch.I Gizeh · tools · sarcophagus workmanship |

## 系列用途

用於：ep1 · ep3 · ep4 · 見各 slug `sources.md` 書名鎖定表

## 原文摘錄

> I found repeatedly that the hard stones, basalt, granite, and diorite, were sawn; and that the saw was not a blade, or wire, used with a hard powder, but was set with fixed cutting points, in fact, a jewelled saw. These saws must have been as much as nine feet in length, as the cuts run lengthwise on the sarcophagi.
> 
> one of the most usual tools was the tubular drill, and this was also set with fixed cutting points; I have a core from inside a drill hole, broken away in the working, which shows the spiral grooves produced by the cutting points as they sunk down into the material

*來源：Spin Map Physical_Reality 正本（只讀抽取）· zip next 2*

## 修改紀錄

- 2026-07-13 · zip next 2 · 厚引述入 `3_citations/`
