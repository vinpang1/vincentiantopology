# Erlitou statistical chronology (T2)

> Spin Map B/A · `gravity_links: kR3mNpW8` · **只讀** · 梯隊 T2  
> 系列 `pyramids` · 用於 ep2

## 書目

| 欄 | 內容 |
|----|------|
| 作者 | Revista, Zen et al. |
| 書名 | *Statistical Chronology of Erlitou: Constraining the Xia Dynasty's Origins* |
| Spin Map `p_path` | `Physical_Reality/B03_History_Culture/20260627_erlitou_statistical_chronology_kR3mNpW8.bin` |
| 章／錨 | Abstract · Bayesian radiocarbon modeling |

## 系列用途

用於：ep2 · 見各 slug `sources.md` 書名鎖定表

## 原文摘錄

> This paper addresses these uncertainties by applying advanced statistical chronological modeling techniques, specifically Bayesian analysis, to a comprehensive dataset of radiocarbon dates from the Erlitou type site and associated cultural manifestations. By integrating these dates with archaeological stratigraphy and cultural phasing, we aim to produce a high-resolution chronological framework for Erlitou.

*來源：Spin Map Physical_Reality 正本（只讀抽取）· zip next 2*

## 修改紀錄

- 2026-07-13 · zip next 2 · 厚引述入 `3_citations/`
