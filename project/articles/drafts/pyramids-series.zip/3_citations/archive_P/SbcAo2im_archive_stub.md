# P* 舊稿封存 · `SbcAo2im`

> **禁止** `gravity_links` · **禁止** copy 入正文 · ep2 舊稿改寫源

原路徑：`草稿區/02-pyramid-china-chronology/20260610_pyramid_china_chronology_SbcAo2im.txt`

## 原文摘錄（自產舊稿 · 非 Spin Map B/A）

> 金字塔年代 × 中國同期：對照與啟示
> 
> 以下對照主要依庫內文獻：埃及（nk8jIIvx Petrie、sOr3Lhqe Rawlinson、2MshQLAD Burr）；中國（SL9cxP8Y Eberhard《A History of China》）。年代有不同學派，文中會標明。
> 
> 
> 一、金字塔大概在什麼時候？
> 
> 來源                          吉薩三大金字塔（胡夫、卡夫拉、孟卡拉）
> Petrie（庫內）                埃及第四王朝，約公元前 4000–3800
> Burr（庫內）                  全埃及金字塔大約公元前 4000–2500；大金字塔距今約五千年
> 現今考古主流（庫外共識，供對照）  胡夫約公元前 2580–2560，卡夫拉、孟卡拉稍後
> 
> 庫內舊書年代偏早；與中國對照時，宜採約公元前 2600–2500 作吉薩興築高峰

*zip next 2 · archive_P only*
