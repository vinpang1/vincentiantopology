# 希羅多德 · An Account of Egypt

> Spin Map B/A · `gravity_links: phVXjCiA` · **只讀** · 梯隊 T3  
> 系列 `pyramids` · 用於 ep1 · ep3 · ep4

## 書目

| 欄 | 內容 |
|----|------|
| 作者 | Herodotus |
| 書名 | *An Account of Egypt (Histories, Book II)* |
| Spin Map `p_path` | `Physical_Reality/B03_History_Culture/20260603_an_account_of_egypt_phVXjCiA.txt` |
| 章／錨 | Cheops · causeway · labour rotation |

## 系列用途

用於：ep1 · ep3 · ep4 · 見各 slug `sources.md` 書名鎖定表

## 原文摘錄

> they worked by a hundred thousand men at a time, for each three months continually. Of this oppression there passed ten years while the causeway was made by which they drew the stones, which causeway they built, and it is a work not much less, as it appears to me, than the pyramid; for the length of it is five furlongs and the breadth ten fathoms and the height, where it is highest, eight fathoms
> 
> For the making of the pyramid itself there passed a period of twenty years

*來源：Spin Map Physical_Reality 正本（只讀抽取）· zip next 2*

## 修改紀錄

- 2026-07-13 · zip next 2 · 厚引述入 `3_citations/`
