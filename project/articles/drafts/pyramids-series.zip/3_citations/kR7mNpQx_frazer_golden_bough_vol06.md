# Frazer · The Golden Bough (Vol. 06)

> Spin Map B/A · `gravity_links: kR7mNpQx` · **只讀** · 梯隊 T3  
> 系列 `pyramids` · 用於 ep4

## 書目

| 欄 | 內容 |
|----|------|
| 作者 | James Frazer |
| 書名 | *The Golden Bough: A Study in Magic and Religion (Vol. 06 of 12)* |
| Spin Map `p_path` | `Physical_Reality/B01_Humanities/20260622_the_golden_bough_vol_06_kR7mNpQx.txt` |
| 章／錨 | Part IV Adonis Attis Osiris · myth of kingship |

## 系列用途

用於：ep4 · 見各 slug `sources.md` 書名鎖定表

## 原文摘錄

> Reigning as a king on earth, Osiris reclaimed the Egyptians from savagery, gave them laws, and taught them to worship the gods. Before his time the Egyptians had been cannibals. But Isis, the sister and wife of Osiris, discovered wheat and barley growing wild, and Osiris introduced the cultivation of these grains amongst his people, who forthwith abandoned cannibalism and took kindly to a corn diet.

*來源：Spin Map Physical_Reality 正本（只讀抽取）· zip next 2*

## 修改紀錄

- 2026-07-13 · zip next 2 · 厚引述入 `3_citations/`
