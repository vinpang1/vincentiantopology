---
title: "Do Alien Claims Hold Up? Three Tests for Evidence-Free Escape Routes"
description: "Ep1's four-cell framework on alien-build claims—math, logistics, and patterns across the pyramid fields."
slug: pyramid-alien-claim-critique
section: topics
series: pyramids
seriesTitle: "Pyramids: Read the Narrative, Don't Buy the Conclusion"
episode: 3
pipeline_stage: en_awaiting_db_confirm
agent_last: legal
lang: en
created: 2026-06-28
revised: 2026-06-28
edit_rules_version: "0.1"
compliance_rules_version: "0.1"
source_lang: zh-Hant
source_revision: "2026-06-28-agent02"
plan_version: "p7SrPl4K-v0.4"
en_glossary: "batch0-20260628"
draft: true
---

# Do Alien Claims Hold Up? Three Tests for Evidence-Free Escape Routes

All Things Are One | Vincentian Topology  
Vincent

## Introduction

Episode one: were the pyramids built by aliens? **I don't know**—but guesses are allowed if you **check them against the evidence**, using the **four-cell framework**: verifiable, reasonable inference, still disputed, honest blank. Episode two used **dual-axis reading**. Here we go back inside the pyramids for the **escape narrative** feeds push most: **alien builders**.

The pattern is fixed: wherever a cell won't fill, slap on "ancients couldn't have." I won't answer with "ancients were amazing." I'll run **three gates**: if you insist on aliens, can the claim land in **the verifiable cell**? Why power, conspiracy, and story still sell—that waits for episode four.

## At a Glance

**Three gates for alien claims (takeaway for this episode)**

| Gate | Test | If not passed… |
|------|------|----------------|
| **① Math** | Post-hoc number fitting or design inference? | Wonder ≠ verifiable evidence |
| **② Logistics** | Feasible at order-of-magnitude? | Rare ≠ impossible |
| **③ System** | Site-wide "non-Earth" pattern? | One-off alien story won't hold |

- **This episode's call:** All three gates fail to fill **the verifiable cell**; alien claims are an **evidence-free escape**, not a **competing hypothesis** alongside archaeology.
- **This episode does not:** Rehearse "who hid the truth" (episode four method toolkit).
- **One practical line:** Before you hear "humans couldn't," ask—**what evidence would the alien version need to add?**
- **Series navigation:** Previous → ep2 *Same Era, Not the Same Stage—What Was China Doing While Giza Rose?* · Next → ep4 *Fact, Inference, Narrative—A Toolkit for Reading Deep Antiquity*

## Gate one: math and precision

"The base perimeter is close to 2π" sounds uncanny. Separate two things: geometry the design already implies, or coincidence noticed after measuring? If the latter, stop at **reasonable inference or still disputed**—don't jump to **verifiable evidence**.

**Flinders Petrie** (British Egyptologist and survey archaeologist, 1853–1942), in *Ten years' digging in Egypt, 1881–1891*, Giza chapter, re-measured the Great Pyramid base. It does not match what most "cosmic code" theories need. Some invoke a vanished platform as a "hidden baseline"—unmeasurable while full casing still stood. What holds better: outer slope about **51°50′**, so base perimeter roughly equals a circle whose radius is the pyramid height. That's pyramid-slope inference; Pythagoras is enough—no alien math.

In the same cluster, Khufu's base error is tiny; the King's Chamber floor is noticeably off-level. Khafre's and Menkaure's pyramids show declining precision. One alien toolkit should not yield three neighbors with quality sliding downhill. **Gate one: not passed**—cherry-pick the tightest stretch and you dress inference as verifiable.

## Gate two: logistics

"More than six million tonnes" does not by itself mean "not human." Ask first: quarrying, Nile transport, worker housing—do they match ancient accounts at **order of magnitude**?

**Burr** (nineteenth-century British engineering writer), in *Ancient and modern engineering and the Isthmian canal*, Chapter 6, puts the Great Pyramid at roughly **2.67 million cubic meters**, nearly **6.3 million tonnes** (about 3.5 million cubic yards and 7 million tons in the original). Rare scale—still an estimable stone pile, not unmeasurable "miracle volume."

**Herodotus** (ancient Greek historian, c. 484–425 BCE), in *An Account of Egypt* (*Histories*, Book II), left an **order-of-magnitude account**: a hundred thousand workers, twenty years (*a hundred thousand men at a time*). Rough count: ~2.3 million blocks at 2–3 tonnes each; twenty years ≈ 7,300 workdays. With resident labor and flood-season water transport, hundreds of blocks per day is not physically impossible at that scale.

Petrie found worker housing at Giza for roughly four thousand people. On those manpower and timeline figures, he judged the Great Pyramid **entirely feasible**—**reasonable inference** as arithmetic check, not romance. **Gate two: not passed**—"rare" read as "impossible" fills **honest blank** with an alien variable instead of testing order of magnitude.

## Gate three: system and materials

Alien intervention at Giza's three pyramids only? Then explain sixty-plus pyramids across Egypt in a predictable tomb tradition with technical drift. **Repeatable pattern** beats a **one-off gift**.

**George Rawlinson** (British historian of antiquity, 1812–1902), in *Ancient Egypt*, reads pyramids as Memphis cemetery tradition: chambers, sarcophagi. Later pyramids tend smaller, poorer materials, tracking dynastic lists and royal titles. He dismisses "observatory" claims and air shafts as telescopes—shafts only inches wide, optically implausible.

Burr and Petrie agree on materials: local limestone bulk, granite at key points; copper-stone tool traces, sawing, tubular drill (*tubular drill*) marks—earthly stuff, human process. Aliens as **competing hypothesis** need verifiable alien residue or physics-breaking construction records. **The verifiable cell** has none so far. **Gate three: not passed**—a one-off gift cannot explain evolution that mixes extreme precision and rough work.

## Summary

After three gates, the point is not "I proved who built them." **Escape narratives bundle wonder, rarity, and honest blank into "aliens certainly did"—and still can't fill the verifiable cell.** The Great Pyramid is extreme; the peak still sits on a spectrum explainable by labor, materials, tools, and organization.

One line to keep: episode one asked "can this line be verified?" This episode asks "what evidence would aliens need?"—usually it can't be added, so it's escape, not competing hypothesis. Next: why **alternative stories still sell** when claims don't hold—fact, inference, and narrative layers.

## Worth Another Look

If aliens built them, what **repeatable, falsifiable** traces would you expect—and what pattern does the Egyptian pyramid field actually show?

## Sources

- Petrie | Ten years' digging in Egypt, 1881–1891 | Ch.I base measures, 2π debate, precision spread, housing and feasibility
- Burr | Ancient and modern engineering and the Isthmian canal | Ch.6 volume estimate and mobilization
- Herodotus | An Account of Egypt (Histories, Book II) | Hundred thousand workers and twenty years order-of-magnitude account
- Rawlinson | Ancient Egypt | Tomb tradition and rebuttal of "observatory" claims

---

## Revision log

- 2026-06-28 · Agent 1 search · EN Batch 5 · faithful translate from zh Agent 2 revision · `en_glossary` batch0 · `pipeline_stage: en_draft`
- 2026-06-28 · Agent 2 · edit_rules 0.1 · EN Batch 6 · voice:en-topics-S3 · surface:R61Wp9W7+TxpluTH3 · `pipeline_stage: en_edit`
- 2026-06-28 · Agent 2 · edit_rules 0.1 · EN Batch 9 · series QA · dual-axis/four-cell aligned · `en_awaiting_legal`
- 2026-06-28 · Agent 4 · compliance 0.1 · pass · alien-claim framing OK · no defamation · `en_awaiting_db_confirm`
