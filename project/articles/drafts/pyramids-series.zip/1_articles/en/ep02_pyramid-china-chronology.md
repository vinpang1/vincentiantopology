---
title: "Same Era, Not the Same Stage—What Was China Doing While Giza Rose?"
description: "Giza's building peak and early China in one time window—dual-axis reading of stage and path, not a contest."
slug: pyramid-china-chronology
section: topics
series: pyramids
seriesTitle: "Pyramids: Read the Narrative, Don't Buy the Conclusion"
episode: 2
pipeline_stage: en_awaiting_db_confirm
agent_last: legal
lang: en
created: 2026-06-28
revised: 2026-06-28
edit_rules_version: "0.1"
compliance_rules_version: "0.1"
source_lang: zh-Hant
source_revision: "2026-06-28-agent02"
plan_version: "p7SrPl4K-v0.4"
en_glossary: "batch0-20260628"
draft: true
---

# Same Era, Not the Same Stage—What Was China Doing While Giza Rose?

All Things Are One | Vincentian Topology  
Vincent

## Introduction

Episode one taught the four-cell framework at Giza: verifiable, reasonable inference, still disputed, honest blank. The natural next question: **In the same era, what was happening elsewhere?** Giza's building peak falls roughly **2600–2500 BCE**. North China and the Yangtze valley were not idle—they were on a different path.

We pull early China into the same window with **dual-axis reading**: the **textual axis** (what histories say) and the **archaeological axis** (how sites are dated). We ask **what stage each region was in**—not who wins. The third millennium BCE speaks two languages on those axes. Read **temporal overlap** as **the same developmental stage** and you **skip a cell**.

## At a Glance

**Dual-axis reading (takeaway for this episode)**

| Axis | Read | Ask first |
|------|------|-----------|
| **Textual axis** | Dynastic chronicles, royal narratives | Contemporary record or later compilation? |
| **Archaeological axis** | Sites, radiocarbon, culture phases | Probability range—or a slogan? |

- **Date anchor:** Giza building peak roughly **2600–2500 BCE** (modern Egyptology consensus).
- **This episode answers:** In that window, what stage were Egypt and North China / the Yangtze in—**side-by-side reading** of both lines.
- **This episode does not answer:** Alien claims, conspiracy narratives, or the full-series method toolkit (last two episodes).
- **Two practical questions:** Am I reading **early China in texts**, or **dates from sites**? Does "same era" mean **the same millennium**, or **the same developmental stage**?
- **Series navigation:** Previous → ep1 *I Don't Know Who Built the Pyramids—But I Know What Doesn't Count as Evidence* · Next → ep3 *Do Alien Claims Hold Up? Three Tests for Evidence-Free Escape Routes*

## Texts first, sites second: two languages for early dates

"Five thousand years of civilization" as a slogan lumps Yao and Shun, the Three Dynasties, and Giza into "the third millennium." There are two books: **how histories record deep antiquity**, and **how sites are dated**. Mix them and "the same era doesn't match."

**On the textual side**, **Wolfram Eberhard** (German-born historian of China, 1909–1989), in *A history of China, 3d ed. rev. and enl.*, Prehistory (Chapter I: PREHISTORY), is blunt: archaeology shows **no trace of any high civilization in the third millennium B.C.** Yao-and-Shun-style royal narratives are **inventions of a much later period**. Yao, Shun, and Three Dynasties chronology can be discussed—mark compilation history or dispute. Don't treat them as **verifiable** site dates. **That is a textual memory scheme, not an archaeological chronology.**

**On the site side**, archaeology rarely pins "which year was the Xia." It uses radiocarbon and strata to place a culture **in a span**. Recent carbon work on Erlitou-type sites speaks that language: a **probability date range**, not a single year—and not a slogan to force onto Giza.

Giza peak (c. 2600 BCE), side by side, simplified:

| | Egypt | Early China (archaeological mainstream) |
|--|-------|----------------------------------------|
| **c. 2600 BCE** | Giza pyramids, state mobilization for tombs | Multiple regional cultures; no unified dynasty or literate state |

Same millennium: Egypt had large stone tombs; North China and the Yangtze had **regional cultures in parallel**—each at its own stage. Treat a textual slogan as a site date and you **skip a cell**. After the Shang, oracle bones, bronze ritual vessels, and royal tombs let texts and digs align—that's later. This episode stays on the Giza-building window.

## Multipolar, out of sync: same era, different paths

For now I read a **multipolar world** where paths diverge. **Geography sets which materials you use**; materials shape engineering and how memory is stored. Limestone and granite come easy along the Nile, with stable river transport. North China and the Yangtze are a different landform and resource mix. One yardstick—giant surface stone, say—and you miss each path.

**George Rawlinson** (British historian of antiquity, 1812–1902), in *Ancient Egypt*, reads Old Kingdom pyramids as the peak of pharaonic tomb tradition—the Giza three are royal burials at heart. North China at this window was regional culture from late Neolithic toward early bronze.

**Later China** buried Shang kings in large **underground tombs** outside cities. Bronze casting was rarely surpassed afterward; the huge mound tombs of later eras did not exist yet. Egypt poured state power into **locally available stone**, piled into visible mountains. **Later China** poured elite resources into bronze ritual, writing, and lineage politics—burials mostly underground and in earth. **Which materials, who dies for whom, how memory is kept**: separate systems.

Did China later show a similar impulse? Yes—in different form. The First Emperor's tomb, the Great Wall, the Grand Canal are state megaprojects too, but in **materials easier locally**: earth, wood, brick, terracotta armies, underground palaces—not surface stone cones. Centralized rule and massive labor exist in both traditions. **Side-by-side reading** shows the differences instead of letting "same era" quietly erase them.

## Summary

Reading Giza and early China together means **dual-axis reading**: textual axis for narrative and compilation history; archaeological axis for sites and probability dates. Episode one asked "can this line be verified?" Add two: **which axis am I on?** Does "same era" mean **the same millennium**, or **the same developmental stage**?

**Visual asymmetry** also drives misreading. Giza pyramids stand in open desert—visible for millennia. North China and the Yangtze at the same window built more in regional culture, ritual, and writing still taking shape—institutions moving, not always ground spectacle at the same scale. **Geography and materials** matter: neither side "should have" built the other's signature form. Measure the era only by "anything as spectacular as the pyramids?" and mismatch comes easily—**conspiracy narratives**, alien builders, other **escape narratives** find a gap. Not because archaeology proved something. Because **the spectacle is loud; the other line is quiet**.

One line to keep: side-by-side reading shows **which civilization line was at which stage** in the same era—don't use the pyramid's visual punch to ask the other line, "what should have been there then?" Next episode: episode one's four-cell framework on the most common escape narrative—alien construction.

## Worth Another Look

Is your "five thousand years" **one line on the textual axis**, or **sites and date ranges on the archaeological axis**? Does unease about "the same era" come from **dates not lining up**, or **spectacle not lining up**?

## Sources

- Eberhard | A history of China, 3d ed. rev. and enl. | Ch.I PREHISTORY: no high civilization in third millennium; "Chinese civilization" from c. 1300 BCE; early narratives as later compilation
- Statistical Chronology of Erlitou | Constraining the Xia Dynasty's Origins | Erlitou radiocarbon + Bayesian modeling; probability date ranges
- Qiu et al. | Chronology of early China: A radiocarbon databank for Chinese archaeology | Chinese archaeology radiocarbon databank; dates updatable
- Rawlinson | Ancient Egypt | Old Kingdom pyramids as pharaonic tomb tradition

---

## Revision log

- 2026-06-28 · Agent 1 search · EN Batch 3 · faithful translate from zh Agent 2 revision · `en_glossary` batch0 · `pipeline_stage: en_draft`
- 2026-06-28 · Agent 2 · edit_rules 0.1 · EN Batch 4 · voice:en-topics-S2 · surface:R61Wp9W7+TxpluTH3 · `pipeline_stage: en_edit`
- 2026-06-28 · Agent 2 · edit_rules 0.1 · EN Batch 9 · series QA · four-cell framework aligned · `en_awaiting_legal`
- 2026-06-28 · Agent 4 · compliance 0.1 · pass · no banned uuid · citations OK · `en_awaiting_db_confirm`
