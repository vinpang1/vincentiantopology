---
title: "I Don't Know Who Built the Pyramids—But I Know What Doesn't Count as Evidence"
description: "Aliens? Human labor? I won't pick a side. This episode maps what you can verify, what you can only infer, and what to leave blank."
slug: pyramid-construction-archaeology
section: topics
series: pyramids
seriesTitle: "Pyramids: Read the Narrative, Don't Buy the Conclusion"
episode: 1
pipeline_stage: en_awaiting_db_confirm
agent_last: legal
lang: en
created: 2026-06-28
revised: 2026-06-28
edit_rules_version: "0.1"
compliance_rules_version: "0.1"
source_lang: zh-Hant
source_revision: "2026-06-28-agent02"
plan_version: "p7SrPl4K-v0.4"
en_glossary: "batch0-20260628"
draft: true
---

# I Don't Know Who Built the Pyramids—But I Know What Doesn't Count as Evidence

All Things Are One | Vincentian Topology  
Vincent

## Introduction

Were the pyramids built by aliens? **I don't know.**

I'm not dodging— I really don't know. We can't walk back onto a Fourth Dynasty construction site. We only have ancient accounts, traces in the ground, and later measurements. I've had hunches too. This series runs on one rule: **Guesses are allowed—but check them against the evidence.**

Social media feeds you complete versions: pharaoh's tomb, sweat-and-toil narrative, alien builders, precision star-alignment—each line sounds eyewitness-sure. A **complete story** turns **inference** into **fact** faster than a careful one. This episode won't judge who built them. We'll map **what is verifiable, what is reasonable inference, what is still disputed, and what should stay an honest blank.** The next three episodes take up dual-axis reading, alien claims, and a toolkit for reading deep antiquity; this one gives you the map.

## At a Glance

**Evidence four-cell framework (takeaway for this episode)**

| Cell | Ask | Meaning |
|------|-----|---------|
| **① Verifiable** | Do site, measurement, and checkable texts hold up? | Others can look too |
| **② Reasonable inference** | Do texts and site fit together, but no one saw it? | Detective work, not eyewitness testimony |
| **③ Still disputed** | Is scholarship still arguing? | Say it—but mark it "unsettled" |
| **④ Honest blank** | Do we honestly not know? | Leave it blank; don't fill with conspiracy or the supernatural |

- **This episode answers:** For the Giza pyramids, which materials in texts and on the ground belong in which cell—and which cannot be forced in as evidence.
- **This episode does not answer:** Whether aliens are real, early China in comparison, or the full-series toolkit for reading deep antiquity (later episodes).
- **One practical line:** Before any paragraph about pyramids, ask—**Can this line be verified—or only inferred, still disputed, or honestly left blank?**
- **Series navigation:** Next → ep2 *Same Era, Not the Same Stage—What Was China Doing While Giza Rose?*

## Tomb context: find minimum shared ground first

Before asking who built them, settle whether this is a **royal tomb**—minimum shared ground for texts and site, mostly in the **verifiable** and **reasonable inference** cells.

**George Rawlinson** (British historian of antiquity, 1812–1902), in *Ancient Egypt*, reads the large Giza pyramids as a royal cemetery across from Memphis: chambers, sarcophagi, built to inter mummies. That pulls the question from "what miracle is this?" to "what kind of site is it?"—**verifiable:** cemetery location and chamber layout; **reasonable inference:** state-led funerary engineering.

"Tomb" does not mean every detail is solved. Looting, how to read some inscriptions—scholarship still debates these. Mark them **still disputed** or **honest blank**. Don't **skip a cell** (treating inference as verified fact) because the story needs it. Once minimum shared ground holds, ask whether materials and labor add up.

## Materials and labor: impressive numbers aren't necessarily a payroll

A hundred thousand workers, twenty years—it sounds like a script line. Separate two things: an **order-of-magnitude narrative**, or a **site attendance roll**?

**Burr** (nineteenth-century British engineering writer), in *Ancient and modern engineering and the Isthmian canal*, Chapter 6, describes Giza work: local limestone for the bulk, granite for load-bearing and fine work. The Great Pyramid's King's Chamber granite came from Upper Egypt—roughly **800 km** by river (about five hundred miles in the original). Materials and long-distance water transport can be traced in the sources; that block sits in **reasonable inference**, on the harder end.

**Herodotus** (ancient Greek historian, c. 484–425 BCE), in *An Account of Egypt* (*Histories*, Book II), left an **order-of-magnitude account** of Khufu's project: quarrying, shipping, crew rotation—**a hundred thousand men at a time**, he says; ten years for the causeway, twenty to raise the pyramid. That is a fifth-century BCE estimate template, not an attendance roll. Whether every detail is true is **still disputed**—mark it as such.

Rawlinson thought the estimate not exaggerated. Modern digs at Giza found worker housing for roughly four thousand people—skilled masons on site, general labor possibly rotating in during Nile flood season when farming idled. That fits "state mobilization plus seasonal labor," still **reasonable inference**.

Readers often miss the gap between "massive project" and "we saw it ourselves." How ramps were rigged, how many shifts per day—mostly **honest blank**. Calling blank space "proved" is like calling dispute "settled": both **skip a cell**.

## Precision: wonder can open the topic; it can't be the evidence

Social media loves to end on "joints too tight" or "humans couldn't do it." I won't follow the wonder. I ask: in the same site cluster, was precision uniform—or mixed, tight and rough together?

**Flinders Petrie** (British Egyptologist and survey archaeologist, 1853–1942), in *Ten years' digging in Egypt, 1881–1891*, Giza chapter, re-surveyed the Great Pyramid by triangulation: tiny base error, extremely fine casing joints—**verifiable**. In the same cluster, the King's Chamber floor is noticeably off-level; Khafre's and Menkaure's pyramids show declining precision. He recorded granite set before the structure was finished, and on site saw saw marks (*jewelled saw*) and tubular drill holes (*tubular drill*)—striking, but on a continuous spectrum of Copper Age stonework: **reasonable inference**, not breakaway "super-technology."

Here **skipping a cell** is easiest: cherry-pick the tightest stretch, call **reasonable inference** **verifiable**, then conclude "humans couldn't." Steadier read: early royal society mobilized labor, water transport, and stoneworking skill over decades to build giant stone tombs—**ceiling high; details still blank.** Wonder opens the question; checking picks the cell.

## Summary

I don't know who built the pyramids. I know what doesn't count as evidence. **Map the four cells first—later arguments need that map**—or you only pick the best-sounding version instead of checking against the evidence.

One line to keep: complete stories turn **reasonable inference** or **still disputed** claims into **verifiable evidence**. Before you hear "ancients couldn't" or "aliens certainly did," ask **can this line be verified?** In episode two we use this map for cross-civilization "same era" reading; then alien escape narratives; then a portable method for reading deep history.

## Worth Another Look

The last time you said "I believe this version" about the pyramids—was it **which verifiable piece of evidence**, or **a story that felt too complete**?

## Sources

- Rawlinson | Ancient Egypt | Memphis cemetery and tomb function
- Burr | Ancient and modern engineering and the Isthmian canal | Ch.6 materials and granite transport
- Herodotus | An Account of Egypt (Histories, Book II) | Khufu labor and timeline order-of-magnitude account
- Petrie | Ten years' digging in Egypt, 1881–1891 | Ch.I Giza triangulation, sarcophagus placement, saw and tubular drill, worker housing

---

## Revision log

- 2026-06-28 · Agent 1 search · EN Batch 1 · faithful translate from zh Agent 2 revision · `en_glossary` batch0 · `pipeline_stage: en_draft`
- 2026-06-28 · Agent 2 · edit_rules 0.1 · EN Batch 2 · voice:en-topics-S1 · surface:R61Wp9W7+TxpluTH3 · split long paras · active/concrete · `pipeline_stage: en_edit`
