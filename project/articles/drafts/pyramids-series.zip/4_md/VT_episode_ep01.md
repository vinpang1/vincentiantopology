---
uuid: VT_episode_ep01
subject_id: VT_sub_episode_ep01
item_type: episode
layer: 实
is_primary_shadow: true
p_path: 1_articles/ep01_pyramid-construction-archaeology.docx
m_path: 4_md/VT_episode_ep01.md
view: ep01_whole
name: "我不知道金字塔是誰建的，但我知道什麼不能當證據"
series_seq: 1
keywords: pyramids|ep1|證據四格
qutrit: "2/1/2/1/2/2"
vsm: "102130210"
topo_links: VT_tool_evidence_grid|VT_citation_nk8jIIvx|VT_citation_sOr3Lhqe|VT_citation_2MshQLAD|VT_citation_phVXjCiA|VT_series_plan|VT_citation_gO5inxjd
gravity_links: ""
---

# doc_summary

外星人？人力？我先不選邊。這一期只畫一張圖：哪些能核對、哪些只能推、哪些該留白。

**slug** `pyramid-construction-archaeology` · **pipeline_stage** `awaiting_draft_confirm` · 正文：`1_articles/ep01_pyramid-construction-archaeology.md` · en：`1_articles/en/ep01_pyramid-construction-archaeology.md` · craft：`2_craft/work_papers/ep01_pyramid-construction-archaeology.md` · docx✓

## 修改紀錄

- 2026-07-13 · zip next 3 · episode shadow
- 2026-07-13 · zip next 4 · docx 交付
- 2026-07-13 · repair next 2 · zh md 源入 1_articles/
- 2026-07-13 · repair next 3 · registry／shadow zip 内路径
