---
uuid: VT_tool_alien_three_gates
subject_id: VT_sub_tool_alien_three_gates
item_type: tool
layer: 虚
is_primary_shadow: true
m_path: 4_md/VT_tool_alien_three_gates.md
view: tool_alien_three_gates
name: 外星三關
series_seq: 3
keywords: pyramids|ep3|tool|外星三關
qutrit: "2/1/1/1/2/2"
vsm: "101120200"
topo_links: VT_series_plan|VT_episode_ep03
gravity_links: ""
---

# doc_summary

Ep3 帶走工具：數學／精度 · 工程量 · 系統與材料。厚文：`2_craft/tool_alien_three_gates.md`
