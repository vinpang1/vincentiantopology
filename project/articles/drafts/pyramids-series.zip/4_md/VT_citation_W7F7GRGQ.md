---
uuid: VT_citation_W7F7GRGQ
subject_id: VT_sub_citation_W7F7GRGQ
item_type: citation
layer: 虚
is_primary_shadow: true
m_path: 4_md/VT_citation_W7F7GRGQ.md
view: citation_eberhard_1st
name: Eberhard · A History of China (Gutenberg 11367)
keywords: pyramids|citation|W7F7GRGQ
qutrit: "1/1/1/0/1/1"
vsm: "211320100"
topo_links: VT_citation_SL9cxP8Y|VT_episode_ep02
gravity_links: W7F7GRGQ
---

# doc_summary

Wolfram Eberhard · A History of China (1st ed. · Gutenberg #11367)。厚文：`3_citations/W7F7GRGQ_eberhard_china_1st.md` · 原文✓ · episodes linked

- 2026-07-13 · repair next 3 · topo → VT_episode_ep02
