---
uuid: VT_tool_china_egypt_axes
subject_id: VT_sub_tool_china_egypt_axes
item_type: tool
layer: 虚
is_primary_shadow: true
m_path: 4_md/VT_tool_china_egypt_axes.md
view: tool_china_egypt_axes
name: 文獻軸／考古軸
series_seq: 2
keywords: pyramids|ep2|tool|雙軸|同期
qutrit: "2/1/1/1/2/2"
vsm: "101120200"
topo_links: VT_series_plan|VT_episode_ep02
gravity_links: ""
---

# doc_summary

Ep2 帶走工具：文獻軸 vs 考古軸；同期 ≠ 同級。厚文：`2_craft/tool_china_egypt_axes.md`
