---
uuid: VT_citation_kR7mNpQx
subject_id: VT_sub_citation_kR7mNpQx
item_type: citation
layer: 虚
is_primary_shadow: true
m_path: 4_md/VT_citation_kR7mNpQx.md
view: citation_frazer
name: Frazer · The Golden Bough (Vol. 06)
keywords: pyramids|citation|kR7mNpQx
qutrit: "1/1/0/0/1/1"
vsm: "000000000"
topo_links: VT_episode_ep04
gravity_links: kR7mNpQx
---

# doc_summary

James Frazer · The Golden Bough: A Study in Magic and Religion (Vol. 06 of 12)。厚文：`3_citations/kR7mNpQx_frazer_golden_bough_vol06.md` · 原文✓ · episodes linked
