---
uuid: VT_citation_kR3mNpW8
subject_id: VT_sub_citation_kR3mNpW8
item_type: citation
layer: 虚
is_primary_shadow: true
m_path: 4_md/VT_citation_kR3mNpW8.md
view: citation_erlitou_stat
name: Erlitou statistical chronology (T2)
keywords: pyramids|citation|kR3mNpW8
qutrit: "1/2/1/0/2/2"
vsm: "001130100"
topo_links: VT_citation_vT2xQmL5|VT_episode_ep02
gravity_links: kR3mNpW8
---

# doc_summary

Revista, Zen et al. · Statistical Chronology of Erlitou: Constraining the Xia Dynasty's Origins。厚文：`3_citations/kR3mNpW8_erlitou_statistical.md` · 原文✓ · episodes linked
