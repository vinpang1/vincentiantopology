---
uuid: VT_tool_method_seven
subject_id: VT_sub_tool_method_seven
item_type: tool
layer: 虚
is_primary_shadow: true
m_path: 4_md/VT_tool_method_seven.md
view: tool_method_seven
name: 讀史前史總裝七項
series_seq: 4
keywords: pyramids|ep4|tool|總裝|陰謀三層
qutrit: "2/1/2/1/2/2"
vsm: "102130210"
topo_links: VT_series_plan|VT_episode_ep04
gravity_links: ""
---

# doc_summary

Ep4 收束：陰謀三層精簡演練（非事實主張）+ 總裝七項。厚文：`2_craft/tool_method_seven.md`
