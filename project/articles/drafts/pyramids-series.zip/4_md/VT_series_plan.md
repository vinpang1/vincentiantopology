---
uuid: VT_series_plan
subject_id: VT_sub_series_plan
item_type: series_meta
layer: 虚
is_primary_shadow: true
m_path: 4_md/VT_series_plan.md
view: series_plan_whole
name: 金字塔系列策劃 v0.4
keywords: pyramids|p7SrPl4K|v0.4|awaiting_draft_confirm
qutrit: "2/1/2/1/2/2"
vsm: "102130200"
topo_links: VT_tool_evidence_grid|VT_tool_china_egypt_axes|VT_tool_alien_three_gates|VT_tool_method_seven|VT_glossary_en|VT_episode_ep01|VT_episode_ep02|VT_episode_ep03|VT_episode_ep04
gravity_links: ""
---

# doc_summary

金字塔四期專題策劃（`p7SrPl4K` v0.4）：四格查案 → 中埃對讀 → 外星三關 → 方法總裝。`pipeline_stage: awaiting_draft_confirm`。

厚文：`2_craft/series-plan.md` · `DELIVERY.md` · `pipeline.md`
