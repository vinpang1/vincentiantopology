---
uuid: VT_tool_evidence_grid
subject_id: VT_sub_tool_evidence_grid
item_type: tool
layer: 虚
is_primary_shadow: true
m_path: 4_md/VT_tool_evidence_grid.md
view: tool_evidence_grid
name: 證據四格
series_seq: 1
keywords: pyramids|ep1|tool|證據四格
qutrit: "2/1/1/1/2/2"
vsm: "101120200"
topo_links: VT_series_plan|VT_episode_ep01
gravity_links: ""
---

# doc_summary

Ep1 帶走工具：可核對／合理推斷／爭議中／空白。厚文：`2_craft/tool_evidence_grid.md`
