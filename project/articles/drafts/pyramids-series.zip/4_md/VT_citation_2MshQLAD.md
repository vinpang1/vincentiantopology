---
uuid: VT_citation_2MshQLAD
subject_id: VT_sub_citation_2MshQLAD
item_type: citation
layer: 虚
is_primary_shadow: true
m_path: 4_md/VT_citation_2MshQLAD.md
view: citation_burr
name: Burr · Pyramids (Ch.6)
keywords: pyramids|citation|2MshQLAD
qutrit: "1/1/1/1/1/1"
vsm: "212210000"
topo_links: VT_episode_ep01|VT_episode_ep03
gravity_links: 2MshQLAD
---

# doc_summary

Burr · Ancient and modern engineering and the Isthmian canal。厚文：`3_citations/2MshQLAD_burr_pyramids.md` · 原文✓ · episodes linked
