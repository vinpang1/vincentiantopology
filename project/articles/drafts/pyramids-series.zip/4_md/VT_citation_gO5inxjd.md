---
uuid: VT_citation_gO5inxjd
subject_id: VT_sub_citation_gO5inxjd
item_type: citation
layer: 虚
is_primary_shadow: true
m_path: 4_md/VT_citation_gO5inxjd.md
view: citation_maspero
name: Maspero · History of Egypt (Vol.2)
keywords: pyramids|citation|gO5inxjd
qutrit: "1/1/1/0/1/1"
vsm: "211320100"
topo_links: VT_episode_ep01
gravity_links: gO5inxjd
---

# doc_summary

Gaston Maspero · History of Egypt, Chaldæa, Syria, Babylonia, and Assyria (Vol. 2)。厚文：`3_citations/gO5inxjd_maspero_corvee.md` · 原文✓ · episodes linked

- 2026-07-13 · repair next 3 · topo → VT_episode_ep01
