---
uuid: VT_episode_ep04
subject_id: VT_sub_episode_ep04
item_type: episode
layer: 实
is_primary_shadow: true
p_path: 1_articles/ep04_pyramid-reading-method.docx
m_path: 4_md/VT_episode_ep04.md
view: ep04_whole
name: "事實、推斷、敘事——讀史前史的方法總裝"
series_seq: 4
keywords: pyramids|ep4|方法總裝
qutrit: "2/1/2/1/2/2"
vsm: "102130210"
topo_links: VT_tool_method_seven|VT_citation_nk8jIIvx|VT_citation_phVXjCiA|VT_citation_kR7mNpQx|VT_citation_sOr3Lhqe|VT_series_plan
gravity_links: ""
---

# doc_summary

金字塔系列 S4 收束：陰謀敘事三層精簡演練（非事實主張）＋四期工具總裝七項。

**slug** `pyramid-reading-method` · **pipeline_stage** `awaiting_draft_confirm` · 正文：`1_articles/ep04_pyramid-reading-method.md` · en：`1_articles/en/ep04_pyramid-reading-method.md` · craft：`2_craft/work_papers/ep04_pyramid-reading-method.md` · docx✓
> **Agent 4 必審**（陰謀演練節 · 非事實主張）

## 修改紀錄

- 2026-07-13 · zip next 3 · episode shadow
- 2026-07-13 · zip next 4 · docx 交付
- 2026-07-13 · repair next 2 · zh md 源入 1_articles/
- 2026-07-13 · repair next 3 · registry／shadow zip 内路径
