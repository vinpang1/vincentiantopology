---
uuid: VT_citation_sOr3Lhqe
subject_id: VT_sub_citation_sOr3Lhqe
item_type: citation
layer: 虚
is_primary_shadow: true
m_path: 4_md/VT_citation_sOr3Lhqe.md
view: citation_rawlinson
name: Rawlinson · Ancient Egypt
keywords: pyramids|citation|sOr3Lhqe
qutrit: "1/1/1/0/1/1"
vsm: "211320100"
topo_links: VT_episode_ep01|VT_episode_ep02|VT_episode_ep03|VT_episode_ep04
gravity_links: sOr3Lhqe
---

# doc_summary

George Rawlinson · Ancient Egypt。厚文：`3_citations/sOr3Lhqe_rawlinson_ancient_egypt.md` · 原文✓ · episodes linked
