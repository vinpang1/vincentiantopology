---
uuid: VT_glossary_en
subject_id: VT_sub_glossary_en
item_type: glossary
layer: 虚
is_primary_shadow: true
m_path: 4_md/VT_glossary_en.md
view: glossary_en_whole
name: EN Translation Bible
keywords: pyramids|en|glossary|p7SrPl4K
qutrit: "2/1/1/1/2/1"
vsm: "101110200"
topo_links: VT_series_plan
gravity_links: ""
---

# doc_summary

英文術語鎖（四期標題、系列觀測點、工具名）。厚文：`2_craft/en-glossary.md`
