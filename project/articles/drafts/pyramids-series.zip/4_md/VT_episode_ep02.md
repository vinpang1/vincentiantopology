---
uuid: VT_episode_ep02
subject_id: VT_sub_episode_ep02
item_type: episode
layer: 实
is_primary_shadow: true
p_path: 1_articles/ep02_pyramid-china-chronology.docx
m_path: 4_md/VT_episode_ep02.md
view: ep02_whole
name: "「同期」不等於「可比」——吉薩築塔時，中國在什麼階段？"
series_seq: 2
keywords: pyramids|ep2|雙軸對讀
qutrit: "2/1/2/1/2/2"
vsm: "102130210"
topo_links: VT_tool_china_egypt_axes|VT_citation_SL9cxP8Y|VT_citation_kR3mNpW8|VT_citation_vT2xQmL5|VT_citation_sOr3Lhqe|VT_series_plan|VT_citation_W7F7GRGQ|VT_citation_bbh1gjCw|VT_citation_ky7XuH3B
gravity_links: ""
---

# doc_summary

金字塔系列 S2：吉薩築塔時把上古中國拉進同一時間窗口——雙軸並讀，看階段與路徑。

**slug** `pyramid-china-chronology` · **pipeline_stage** `awaiting_draft_confirm` · 正文：`1_articles/ep02_pyramid-china-chronology.md` · en：`1_articles/en/ep02_pyramid-china-chronology.md` · craft：`2_craft/work_papers/ep02_pyramid-china-chronology.md` · docx✓

## 修改紀錄

- 2026-07-13 · zip next 3 · episode shadow
- 2026-07-13 · zip next 4 · docx 交付
- 2026-07-13 · repair next 2 · zh md 源入 1_articles/
- 2026-07-13 · repair next 3 · registry／shadow zip 内路径
