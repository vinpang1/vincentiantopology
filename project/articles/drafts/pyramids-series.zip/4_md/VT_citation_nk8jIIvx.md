---
uuid: VT_citation_nk8jIIvx
subject_id: VT_sub_citation_nk8jIIvx
item_type: citation
layer: 虚
is_primary_shadow: true
m_path: 4_md/VT_citation_nk8jIIvx.md
view: citation_petrie
name: Petrie · Ten years' digging
keywords: pyramids|citation|nk8jIIvx
qutrit: "1/1/1/0/1/1"
vsm: "211320100"
topo_links: VT_episode_ep01|VT_episode_ep03|VT_episode_ep04
gravity_links: nk8jIIvx
---

# doc_summary

Flinders Petrie · Ten years' digging in Egypt, 1881–1891。厚文：`3_citations/nk8jIIvx_petrie_ten_years.md` · 原文✓ · episodes linked
