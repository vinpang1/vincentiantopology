---
uuid: VT_citation_phVXjCiA
subject_id: VT_sub_citation_phVXjCiA
item_type: citation
layer: 虚
is_primary_shadow: true
m_path: 4_md/VT_citation_phVXjCiA.md
view: citation_herodotus
name: 希羅多德 · An Account of Egypt
keywords: pyramids|citation|phVXjCiA
qutrit: "1/1/1/0/1/1"
vsm: "212210110"
topo_links: VT_episode_ep01|VT_episode_ep03|VT_episode_ep04
gravity_links: phVXjCiA
---

# doc_summary

Herodotus · An Account of Egypt (Histories, Book II)。厚文：`3_citations/phVXjCiA_herodotus_egypt.md` · 原文✓ · episodes linked
