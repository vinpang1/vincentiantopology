---
uuid: VT_episode_ep03
subject_id: VT_sub_episode_ep03
item_type: episode
layer: 实
is_primary_shadow: true
p_path: 1_articles/ep03_pyramid-alien-claim-critique.docx
m_path: 4_md/VT_episode_ep03.md
view: ep03_whole
name: "外星說過不過關？——用三關檢驗「證據不足」的逃逸"
series_seq: 3
keywords: pyramids|ep3|外星三關
qutrit: "2/1/2/1/2/2"
vsm: "102130210"
topo_links: VT_tool_alien_three_gates|VT_citation_nk8jIIvx|VT_citation_2MshQLAD|VT_citation_phVXjCiA|VT_citation_sOr3Lhqe|VT_series_plan
gravity_links: ""
---

# doc_summary

金字塔系列 S3：用第一期的四格，檢驗外星建造假說——數學、工程量、遺址系統各過一關。

**slug** `pyramid-alien-claim-critique` · **pipeline_stage** `awaiting_draft_confirm` · 正文：`1_articles/ep03_pyramid-alien-claim-critique.md` · en：`1_articles/en/ep03_pyramid-alien-claim-critique.md` · craft：`2_craft/work_papers/ep03_pyramid-alien-claim-critique.md` · docx✓

## 修改紀錄

- 2026-07-13 · zip next 3 · episode shadow
- 2026-07-13 · zip next 4 · docx 交付
- 2026-07-13 · repair next 2 · zh md 源入 1_articles/
- 2026-07-13 · repair next 3 · registry／shadow zip 内路径
