---
uuid: VT_citation_SL9cxP8Y
subject_id: VT_sub_citation_SL9cxP8Y
item_type: citation
layer: 虚
is_primary_shadow: true
m_path: 4_md/VT_citation_SL9cxP8Y.md
view: citation_eberhard_3d
name: Eberhard · A history of China (3d ed.)
keywords: pyramids|citation|SL9cxP8Y
qutrit: "1/1/1/0/1/1"
vsm: "211320100"
topo_links: VT_citation_W7F7GRGQ|VT_episode_ep02
gravity_links: SL9cxP8Y
---

# doc_summary

Wolfram Eberhard · A history of China, 3d ed. rev. and enl.。厚文：`3_citations/SL9cxP8Y_eberhard_china_3d.md` · 原文✓ · episodes linked
