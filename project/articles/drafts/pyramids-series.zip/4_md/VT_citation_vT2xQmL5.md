---
uuid: VT_citation_vT2xQmL5
subject_id: VT_sub_citation_vT2xQmL5
item_type: citation
layer: 虚
is_primary_shadow: true
m_path: 4_md/VT_citation_vT2xQmL5.md
view: citation_china_c14
name: Qiu et al. · China radiocarbon databank (T2)
keywords: pyramids|citation|vT2xQmL5
qutrit: "1/2/1/0/2/2"
vsm: "001130100"
topo_links: VT_citation_kR3mNpW8|VT_episode_ep02
gravity_links: vT2xQmL5
---

# doc_summary

Menghan Qiu; Linyao Du; Richard Staff; et al. · Chronology of early China: A radiocarbon databank for Chinese archaeology。厚文：`3_citations/vT2xQmL5_china_radiocarbon_databank.md` · 原文✓ · episodes linked
