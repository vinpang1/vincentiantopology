---
uuid: VT_citation_ky7XuH3B
subject_id: VT_sub_citation_ky7XuH3B
item_type: citation
layer: 虚
is_primary_shadow: true
m_path: 4_md/VT_citation_ky7XuH3B.md
view: citation_baikie
name: Baikie · Peeps at Many Lands: Ancient Egypt
keywords: pyramids|citation|ky7XuH3B
qutrit: "1/1/1/0/1/1"
vsm: "211320100"
topo_links: VT_episode_ep02
gravity_links: ky7XuH3B
---

# doc_summary

James Baikie · Peeps at Many Lands: Ancient Egypt。厚文：`3_citations/ky7XuH3B_baikie_peeps_egypt.md` · 原文✓ · episodes linked

- 2026-07-13 · repair next 3 · topo → VT_episode_ep02
