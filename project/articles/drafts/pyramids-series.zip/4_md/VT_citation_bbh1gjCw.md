---
uuid: VT_citation_bbh1gjCw
subject_id: VT_sub_citation_bbh1gjCw
item_type: citation
layer: 虚
is_primary_shadow: true
m_path: 4_md/VT_citation_bbh1gjCw.md
view: citation_giles
name: Giles · China and the Chinese
keywords: pyramids|citation|bbh1gjCw
qutrit: "1/1/1/0/1/1"
vsm: "211320100"
topo_links: VT_episode_ep02
gravity_links: bbh1gjCw
---

# doc_summary

Herbert A. Giles · China and the Chinese。厚文：`3_citations/bbh1gjCw_giles_china_greek.md` · 原文✓ · episodes linked

- 2026-07-13 · repair next 3 · topo → VT_episode_ep02
